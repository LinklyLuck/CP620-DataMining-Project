import numpy as np
import pandas as pd



# Activation + loss helpers

def sigmoid(z):
    """Sigmoid activation. Should be numerically stable for large |z|."""
    z = np.asarray(z, dtype=float)              # accept scalars / lists too
    out = np.zeros_like(z)                      # container for the answer
    pos = z >= 0                                # split by sign so exp() never overflows
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))    # safe form when z >= 0
    e = np.exp(z[~pos])                         # exp of a negative number is <= 1
    out[~pos] = e / (1.0 + e)                   # safe form when z < 0
    return out


def sigmoid_derivative_from_activation(a):
    """Derivative dsigmoid(z)/dz evaluated at z, given a = sigmoid(z).

    Useful identity: sigmoid'(z) = a * (1 - a).
    """
    return a * (1.0 - a)                        # straight from the identity above


def binary_cross_entropy(y_true, y_pred, eps=1e-12):
    """Mean binary cross-entropy. Clip y_pred to [eps, 1-eps] to avoid log(0)."""
    y_true = np.asarray(y_true, dtype=float).ravel()
    y_pred = np.asarray(y_pred, dtype=float).ravel()
    y_pred = np.clip(y_pred, eps, 1.0 - eps)    # keep log() away from 0
    loss = -(y_true * np.log(y_pred) + (1.0 - y_true) * np.log(1.0 - y_pred))
    return float(np.mean(loss))                 # average over the batch



# Main MNN classifier

class MultilayerNeuralNetwork:
    """
    Feed-forward neural network with one hidden layer.

    Parameters
    ----------
    hidden_units : int
        Number of units in the hidden layer (default 16).
    learning_rate : float
        Initial SGD learning rate (default 0.01).
    momentum : float
        Momentum coefficient (default 0.9).
    batch_size : int
        Mini-batch size (default 16).
    max_epochs : int
        Hard cap on training epochs (default 200).
    early_stopping_patience : int
        Stop if validation loss doesn't improve for this many epochs (default 10).
    validation_fraction : float
        Fraction of training data held out for early-stopping check (default 0.1).
    seed : int
        RNG seed for weight init + mini-batch shuffling.
    lr_decay : float
        Time-based decay: lr_t = learning_rate / (1 + lr_decay * epoch) (default 0.01).
    """

    def __init__(self, hidden_units=16, learning_rate=0.01, momentum=0.9,
                 batch_size=16, max_epochs=200, early_stopping_patience=10,
                 validation_fraction=0.1, seed=42, lr_decay=0.01):
        self.hidden_units = hidden_units
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.early_stopping_patience = early_stopping_patience
        self.validation_fraction = validation_fraction
        self.seed = seed
        self.lr_decay = lr_decay

        # Fitted parameters (set after .fit())
        self.classes_ = None
        self.W1 = None  # (n_features, H)
        self.b1 = None  # (H,)
        self.W2 = None  # (H, 1)
        self.b2 = None  # (1,)
        self.feature_means_ = None
        self.feature_stds_ = None
        self.feature_names_ = None
        self.training_history_ = None  # list of (epoch, train_loss, val_loss)
        self.n_epochs_run_ = None      # how many epochs actually ran before early stop
        self.best_val_loss_ = None     # best validation loss seen
        self._rng = None               # RNG reused for mini-batch shuffling

    # preprocessing 
    def _standardize_fit(self, X):
        """Compute per-feature mean and std on training data; store them."""
        X = np.asarray(X, dtype=float)
        self.feature_means_ = X.mean(axis=0)
        self.feature_stds_ = X.std(axis=0)
        # 0/1 columns are already on a common scale, so leave them alone
        binary = np.all((X == 0) | (X == 1), axis=0)
        self.feature_means_[binary] = 0.0
        self.feature_stds_[binary] = 1.0
        # a constant column would divide by zero, so pin its std to 1
        self.feature_stds_[self.feature_stds_ < 1e-12] = 1.0
        return self._standardize_transform(X)

    def _standardize_transform(self, X):
        """Apply stored standardization (z-score) to new data."""
        X = np.asarray(X, dtype=float)
        return (X - self.feature_means_) / self.feature_stds_

    #  weight init 
    def _init_weights(self, n_features):
        """Small uniform-random init in [-0.5/sqrt(d), +0.5/sqrt(d)]."""
        self._rng = np.random.default_rng(self.seed)
        limit1 = 0.5 / np.sqrt(n_features)          # fan-in of the hidden layer
        limit2 = 0.5 / np.sqrt(self.hidden_units)   # fan-in of the output layer
        self.W1 = self._rng.uniform(-limit1, limit1, size=(n_features, self.hidden_units))
        self.b1 = np.zeros(self.hidden_units)       # biases start at 0
        self.W2 = self._rng.uniform(-limit2, limit2, size=(self.hidden_units, 1))
        self.b2 = np.zeros(1)

    #  forward / backward 
    def _forward(self, X_std):
        """
        Forward pass on standardized inputs.

        Parameters
        X_std : (n, n_features) numpy array

        Returns
        a1 : (n, H)  hidden-layer activations after sigmoid
        a2 : (n,)    output activations (predicted P(y=1))
        """
        z1 = X_std @ self.W1 + self.b1      # hidden pre-activation (net_j)
        a1 = sigmoid(z1)                    # hidden activation
        z2 = a1 @ self.W2 + self.b2         # output pre-activation (net_k)
        a2 = sigmoid(z2).ravel()            # squash to P(y=1), shape (n,)
        return a1, a2

    def _backward(self, X_std, y, a1, a2):
        """
        Backpropagation. Compute gradients of mean BCE loss w.r.t.
        W1, b1, W2, b2 using the sensitivities delta from the MNN lecture.

        Returns
        dW1, db1, dW2, db2
        """
        n = len(y)
        # output sensitivity: sigmoid and BCE cancel down to (a2 - y)
        delta2 = ((a2 - y) / n).reshape(-1, 1)                  # (n, 1)
        dW2 = a1.T @ delta2                                     # (H, 1)
        db2 = delta2.sum(axis=0)                                # (1,)
        # hidden sensitivity: push delta2 back through W2, then through sigmoid'
        delta1 = (delta2 @ self.W2.T) * sigmoid_derivative_from_activation(a1)
        dW1 = X_std.T @ delta1                                  # (d, H)
        db1 = delta1.sum(axis=0)                                # (H,)
        return dW1, db1, dW2, db2

    # training 
    def _val_split(self, y01):
        """Stratified train/validation split used only for early stopping."""
        rng = np.random.default_rng(self.seed + 1)
        tr_parts, va_parts = [], []
        for c in (0.0, 1.0):
            idx = np.where(y01 == c)[0]
            rng.shuffle(idx)                                    # shuffle inside each class
            n_val = int(round(self.validation_fraction * len(idx)))
            n_val = min(max(n_val, 1), len(idx) - 1)            # keep both parts non-empty
            va_parts.append(idx[:n_val])
            tr_parts.append(idx[n_val:])
        return np.concatenate(tr_parts), np.concatenate(va_parts)

    def fit(self, X, y):
        """
        Train via mini-batch SGD with momentum and early stopping.
        """
        X = pd.DataFrame(X)
        self.feature_names_ = list(X.columns)
        X = X.to_numpy(dtype=float)
        y = np.asarray(y).ravel()

        self.classes_ = np.array(sorted(np.unique(y)))
        assert len(self.classes_) == 2, "this MNN is binary only"
        y01 = (y == self.classes_[1]).astype(float)             # positive class becomes 1.0

        X_std = self._standardize_fit(X)                        # scale using training fold only
        self._init_weights(X_std.shape[1])

        # split off a small validation slice to watch for overfitting
        tr_idx, va_idx = self._val_split(y01)
        X_tr, y_tr = X_std[tr_idx], y01[tr_idx]
        X_va, y_va = X_std[va_idx], y01[va_idx]

        # momentum buffers, one per parameter
        v_W1 = np.zeros_like(self.W1)
        v_b1 = np.zeros_like(self.b1)
        v_W2 = np.zeros_like(self.W2)
        v_b2 = np.zeros_like(self.b2)

        best_val = np.inf
        best_state = None
        bad_epochs = 0
        self.training_history_ = []

        for epoch in range(self.max_epochs):
            lr = self.learning_rate / (1.0 + self.lr_decay * epoch)   # decay the step size
            order = self._rng.permutation(len(X_tr))                  # reshuffle every epoch

            for start in range(0, len(order), self.batch_size):
                b = order[start:start + self.batch_size]              # one mini-batch
                a1, a2 = self._forward(X_tr[b])
                dW1, db1, dW2, db2 = self._backward(X_tr[b], y_tr[b], a1, a2)
                # momentum: keep part of the old step, then add the new gradient step
                v_W1 = self.momentum * v_W1 - lr * dW1
                v_b1 = self.momentum * v_b1 - lr * db1
                v_W2 = self.momentum * v_W2 - lr * dW2
                v_b2 = self.momentum * v_b2 - lr * db2
                self.W1 += v_W1
                self.b1 += v_b1
                self.W2 += v_W2
                self.b2 += v_b2

            # end of epoch: record both losses
            train_loss = binary_cross_entropy(y_tr, self._forward(X_tr)[1])
            val_loss = binary_cross_entropy(y_va, self._forward(X_va)[1])
            self.training_history_.append((epoch, train_loss, val_loss))

            if val_loss < best_val - 1e-6:              # counts as a real improvement
                best_val = val_loss
                best_state = (self.W1.copy(), self.b1.copy(),
                              self.W2.copy(), self.b2.copy())
                bad_epochs = 0
            else:
                bad_epochs += 1
                if bad_epochs >= self.early_stopping_patience:
                    break                               # stop, we are only overfitting now

        if best_state is not None:                      # roll back to the best epoch
            self.W1, self.b1, self.W2, self.b2 = best_state
        self.n_epochs_run_ = len(self.training_history_)
        self.best_val_loss_ = best_val
        return self

    #prediction
    def predict_proba(self, X):
        """
        Return (n, 2) array. Columns are P(y=0), P(y=1) ordered by self.classes_.
        """
        X = np.asarray(pd.DataFrame(X), dtype=float)
        p1 = self._forward(self._standardize_transform(X))[1]   # P(positive class)
        return np.column_stack([1.0 - p1, p1])                  # classes_ is sorted, so [0, 1]

    def predict(self, X):
        """Predicted class labels (n,)."""
        p1 = self.predict_proba(X)[:, 1]
        return self.classes_[(p1 >= 0.5).astype(int)]           # 0.5 is the default threshold

    #diagnostics
    def get_n_params(self):
        """Total trainable parameters: W1 + b1 + W2 + b2."""
        return int(self.W1.size + self.b1.size + self.W2.size + self.b2.size)

    def plot_training_curve(self, ax=None):
        """Plot train_loss and val_loss vs epoch (for the report figure)."""
        import matplotlib.pyplot as plt
        if ax is None:
            _, ax = plt.subplots(figsize=(7, 4))
        hist = np.array(self.training_history_)
        ax.plot(hist[:, 0], hist[:, 1], label='train loss', linewidth=2)
        ax.plot(hist[:, 0], hist[:, 2], label='validation loss', linewidth=2)
        best = int(np.argmin(hist[:, 2]))                       # epoch early stopping kept
        ax.axvline(best, color='grey', linestyle='--', alpha=0.7,
                   label=f'best epoch = {best}')
        ax.set_xlabel('epoch')
        ax.set_ylabel('binary cross-entropy')
        ax.set_title(f'MNN training curve (H={self.hidden_units}, '
                     f'lr={self.learning_rate}, batch={self.batch_size})')
        ax.legend()
        ax.grid(alpha=0.3)
        return ax


# Numerical gradient check (the headline of Week 7 — verifies BP is correct)
def numerical_gradient_check(mnn, X_small, y_small, epsilon=1e-5, tolerance=1e-5):
    """
    Verify analytical backpropagation gradients against finite differences.

    Returns
    max_relative_error : float
    passed : bool
    """
    X = np.asarray(pd.DataFrame(X_small), dtype=float)
    y = np.asarray(y_small, dtype=float).ravel()

    if mnn.W1 is None:                          # untrained model, so set it up first
        X_std = mnn._standardize_fit(X)
        mnn._init_weights(X_std.shape[1])
        mnn.classes_ = np.array([0, 1])
    else:
        X_std = mnn._standardize_transform(X)

    # analytical gradients from one backward pass
    a1, a2 = mnn._forward(X_std)
    grads = mnn._backward(X_std, y, a1, a2)
    params = [mnn.W1, mnn.b1, mnn.W2, mnn.b2]

    max_relative_error = 0.0
    for P, G in zip(params, grads):
        for idx in np.ndindex(P.shape):         # nudge one weight at a time
            original = P[idx]
            P[idx] = original + epsilon
            loss_plus = binary_cross_entropy(y, mnn._forward(X_std)[1])
            P[idx] = original - epsilon
            loss_minus = binary_cross_entropy(y, mnn._forward(X_std)[1])
            P[idx] = original                   # always put the weight back
            numeric = (loss_plus - loss_minus) / (2 * epsilon)   # central difference
            analytic = G[idx]
            denom = max(1e-8, abs(numeric) + abs(analytic))      # relative, not absolute
            max_relative_error = max(max_relative_error, abs(numeric - analytic) / denom)

    return max_relative_error, max_relative_error < tolerance


# Inner-CV hyperparameter selection helper (same protocol the Decision Tree uses)
def select_mnn_hyperparams(X, y, candidate_hidden=(8, 16, 32),
                           candidate_lr=(0.01, 0.05, 0.1),
                           candidate_batch=(16, 32, 64),
                           n_inner_splits=3, seeds=(42, 7, 2024), verbose=False):
    """
    Pick (hidden_units, learning_rate, batch_size) by inner stratified 3-fold CV on F1.

    The whole inner CV is repeated over several seeds and averaged, because a single
    seed on this dataset produces differences that are pure noise.

    Returns (best_hidden, best_lr, best_batch, best_f1, all_rows).
    """
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import f1_score, roc_auc_score

    X = pd.DataFrame(X).reset_index(drop=True)
    y = np.asarray(y).astype(int)

    # one set of inner folds per seed
    fold_sets = {s: list(StratifiedKFold(n_splits=n_inner_splits, shuffle=True,
                                         random_state=s).split(np.zeros(len(y)), y))
                 for s in seeds}

    best = None
    rows = []
    for H in candidate_hidden:
        for lr in candidate_lr:
            for bs in candidate_batch:
                f1s, aucs, epochs = [], [], []
                for s in seeds:
                    for tr, va in fold_sets[s]:
                        mnn = MultilayerNeuralNetwork(hidden_units=H, learning_rate=lr,
                                                      batch_size=bs, seed=s)
                        mnn.fit(X.iloc[tr], y[tr])
                        pred = mnn.predict(X.iloc[va])
                        proba = mnn.predict_proba(X.iloc[va])[:, 1]
                        f1s.append(f1_score(y[va], pred, zero_division=0))
                        aucs.append(roc_auc_score(y[va], proba))
                        epochs.append(mnn.n_epochs_run_)
                mean_f1, mean_auc = float(np.mean(f1s)), float(np.mean(aucs))
                rows.append({'hidden_units': H, 'learning_rate': lr, 'batch_size': bs,
                             'f1': mean_f1, 'f1_std': float(np.std(f1s)),
                             'auc': mean_auc, 'mean_epochs': float(np.mean(epochs))})
                if verbose:
                    print(f"  H={H:<3d} lr={lr:<5} batch={bs:<3d} -> "
                          f"F1={mean_f1:.4f}  AUC={mean_auc:.4f}  "
                          f"epochs={np.mean(epochs):.0f}")
                if best is None or mean_f1 > best[3]:
                    best = (H, lr, bs, mean_f1)
    return best[0], best[1], best[2], best[3], rows


# Standalone smoke test
if __name__ == '__main__':
    rng = np.random.default_rng(0)

    # 1. Tiny synthetic 2D dataset: two well-separated Gaussians
    n = 200
    X0 = rng.normal(loc=[-1.5, -1.5], scale=0.8, size=(n, 2))   # class 0 blob
    X1 = rng.normal(loc=[+1.5, +1.5], scale=0.8, size=(n, 2))   # class 1 blob
    X_toy = pd.DataFrame(np.vstack([X0, X1]), columns=['x1', 'x2'])
    y_toy = np.concatenate([np.zeros(n, dtype=int), np.ones(n, dtype=int)])

    # 2. Fit and confirm the training loss actually goes down
    mnn = MultilayerNeuralNetwork(hidden_units=8, learning_rate=0.05,
                                  batch_size=16, max_epochs=200, seed=42)
    mnn.fit(X_toy, y_toy)
    first_loss = mnn.training_history_[0][1]
    last_loss = mnn.training_history_[-1][1]
    print("=== MNN smoke test on 2 Gaussian blobs ===")
    print(f"  epochs run       : {mnn.n_epochs_run_}")
    print(f"  train loss first : {first_loss:.4f}")
    print(f"  train loss last  : {last_loss:.4f}")
    print(f"  loss decreased   : {last_loss < first_loss}")
    assert last_loss < first_loss, "training loss did not decrease"

    # 3. Numerical gradient check on a small slice with a fresh network
    check_net = MultilayerNeuralNetwork(hidden_units=4, seed=7)
    idx = rng.choice(len(X_toy), size=25, replace=False)         # small batch is enough
    max_err, passed = numerical_gradient_check(check_net,
                                               X_toy.iloc[idx],
                                               y_toy[idx].astype(float))
    print(f"  gradient check   : max relative error = {max_err:.2e}, passed = {passed}")
    assert passed, "backpropagation gradients do not match finite differences"

    # 4. Final training accuracy
    acc = (mnn.predict(X_toy) == y_toy).mean()
    print(f"  training accuracy: {acc:.3f}")
    print(f"  trainable params : {mnn.get_n_params()}")
