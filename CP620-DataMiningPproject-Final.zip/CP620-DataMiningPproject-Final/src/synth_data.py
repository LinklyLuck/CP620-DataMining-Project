"""Synthetic data augmentation for the BRFSS project (Week 10 follow-up).

The Week 8-9 learning curve on real data was flat, so the professor asked whether
augmenting the sample synthetically changes anything. Two generators are provided
so the answer can be controlled rather than guessed:

  smote_nc()   -- SMOTE for mixed data: interpolate between a row and one of its
                  k nearest neighbours of the same class. Continuous columns are
                  interpolated, ordinal columns are interpolated then rounded to a
                  legal level, and binary columns are inherited from one parent
                  (a value of 0.43 for "HighBP" would not be a real person).

  bootstrap()  -- plain resampling with replacement. This is the CONTROL: it adds
                  no information at all, only copies. If SMOTE scores the same as
                  bootstrap, then SMOTE added no information either.

IMPORTANT: synthetic rows are only ever added to a TRAINING fold. Every score in
the experiment is measured on real, held-out rows. Testing on synthetic rows would
inflate the result, because those rows are interpolated from the training data.
"""

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors

# which columns may be interpolated, and which must stay on legal levels
CONTINUOUS = ['BMI', 'MentHlth', 'PhysHlth']
ORDINAL = ['Diabetes', 'GenHlth', 'Age', 'Education', 'Income']


def _column_kinds(X):
    """Split the columns into continuous / ordinal / binary."""
    cont = [c for c in X.columns if c in CONTINUOUS]
    ordi = [c for c in X.columns if c in ORDINAL]
    binary = [c for c in X.columns if c not in cont and c not in ordi]
    return cont, ordi, binary


def smote_nc(X, y, n_target, k=5, seed=42):
    """Grow (X, y) to n_target rows with SMOTE, keeping the class balance.

    Returns a new (X_aug, y_aug) where the original rows come first.
    """
    rng = np.random.default_rng(seed)
    cont, ordi, binary = _column_kinds(X)
    legal = {c: np.sort(X[c].unique()) for c in ordi}      # allowed levels per column

    n_extra = n_target - len(X)
    if n_extra <= 0:
        return X.reset_index(drop=True), y.reset_index(drop=True)

    new_rows, new_y = [], []
    for cls in np.sort(y.unique()):
        Xc = X[y == cls].reset_index(drop=True)
        share = (y == cls).mean()                          # keep the original balance
        n_make = int(round(n_extra * share))
        if n_make == 0 or len(Xc) < 2:
            continue

        # neighbours are found on standardised columns so BMI does not dominate
        Z = Xc.to_numpy(dtype=float)
        sd = Z.std(axis=0); sd[sd == 0] = 1.0
        Zs = (Z - Z.mean(axis=0)) / sd
        kk = min(k, len(Xc) - 1)
        nn = NearestNeighbors(n_neighbors=kk + 1).fit(Zs)  # +1 because self is included
        _, idx = nn.kneighbors(Zs)

        base_i = rng.integers(0, len(Xc), size=n_make)      # the row we start from
        nb_pick = rng.integers(1, kk + 1, size=n_make)      # skip column 0 (itself)
        nb_i = idx[base_i, nb_pick]
        lam = rng.random(n_make)                            # interpolation weight
        take_base = rng.random(n_make) < 0.5                # which parent gives binaries

        A = Xc.iloc[base_i].reset_index(drop=True)
        B = Xc.iloc[nb_i].reset_index(drop=True)
        out = A.copy()

        for c in cont:                                      # interpolate, then round
            v = A[c].to_numpy(float) + lam * (B[c].to_numpy(float) - A[c].to_numpy(float))
            out[c] = np.rint(v)
        for c in ordi:                                      # interpolate, snap to a level
            v = A[c].to_numpy(float) + lam * (B[c].to_numpy(float) - A[c].to_numpy(float))
            lv = legal[c]
            out[c] = lv[np.abs(v[:, None] - lv[None, :]).argmin(axis=1)]
        for c in binary:                                    # inherit, never average
            out[c] = np.where(take_base, A[c].to_numpy(), B[c].to_numpy())

        new_rows.append(out)
        new_y.append(np.full(len(out), cls))

    X_aug = pd.concat([X.reset_index(drop=True)] + new_rows, ignore_index=True)
    y_aug = pd.concat([y.reset_index(drop=True),
                       pd.Series(np.concatenate(new_y))], ignore_index=True)
    return X_aug, y_aug


def bootstrap(X, y, n_target, seed=42):
    """Control generator: grow to n_target by copying existing rows at random."""
    rng = np.random.default_rng(seed)
    n_extra = n_target - len(X)
    if n_extra <= 0:
        return X.reset_index(drop=True), y.reset_index(drop=True)
    pick = rng.integers(0, len(X), size=n_extra)            # sample with replacement
    X_aug = pd.concat([X.reset_index(drop=True), X.iloc[pick].reset_index(drop=True)],
                      ignore_index=True)
    y_aug = pd.concat([y.reset_index(drop=True), y.iloc[pick].reset_index(drop=True)],
                      ignore_index=True)
    return X_aug, y_aug


def sanity_report(X_real, X_syn):
    """Check the synthetic rows are legal and look like the real ones."""
    cont, ordi, binary = _column_kinds(X_real)
    problems = []
    for c in binary:                                        # binary must stay 0/1
        bad = int((~X_syn[c].isin(X_real[c].unique())).sum())
        if bad:
            problems.append(f"{c}: {bad} illegal values")
    for c in ordi:                                          # ordinal must stay on levels
        bad = int((~X_syn[c].isin(X_real[c].unique())).sum())
        if bad:
            problems.append(f"{c}: {bad} off-level values")
    for c in cont:                                          # continuous must stay in range
        bad = int(((X_syn[c] < X_real[c].min()) | (X_syn[c] > X_real[c].max())).sum())
        if bad:
            problems.append(f"{c}: {bad} out-of-range values")
    drift = {c: float(abs(X_syn[c].mean() - X_real[c].mean())) for c in X_real.columns}
    return {'illegal': problems,
            'max_mean_drift': max(drift.values()),
            'worst_column': max(drift, key=drift.get)}
