FEATURE_GROUPS = {
    'chronic_disease': ['HighBP', 'HighChol', 'CholCheck', 'Stroke', 'Diabetes'],
    'lifestyle':       ['Smoker', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump'],
    'body_health':     ['BMI', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk'],
    'demographics':    ['Sex', 'Age', 'Education', 'Income'],
    'healthcare':      ['AnyHealthcare', 'NoDocbcCost'],
}

GROUP_ORDER = ['chronic_disease', 'lifestyle', 'body_health', 'demographics', 'healthcare']

# Build incremental subsets: 5, 10, 15, 19, 21 features
INCREMENTAL_SUBSETS = []
_cumulative = []
for group_name in GROUP_ORDER:
    _cumulative = _cumulative + FEATURE_GROUPS[group_name]
    INCREMENTAL_SUBSETS.append(list(_cumulative))

SUBSET_LABELS = [f"{len(s)} features (+{GROUP_ORDER[i]})"
                 for i, s in enumerate(INCREMENTAL_SUBSETS)]

ALL_FEATURES = INCREMENTAL_SUBSETS[-1]

# Type hints — used by Naive Bayes to decide categorical vs Gaussian likelihood
CONTINUOUS_FEATURES = {'BMI', 'MentHlth', 'PhysHlth'}
# Everything else in ALL_FEATURES is categorical/ordinal for NB purposes


if __name__ == '__main__':
    print("Incremental feature subsets:\n")
    for label, subset in zip(SUBSET_LABELS, INCREMENTAL_SUBSETS):
        print(f"  {label}:")
        print(f"    {subset}\n")
    assert len(ALL_FEATURES) == 21, f"expected 21 features, got {len(ALL_FEATURES)}"
    assert len(set(ALL_FEATURES)) == 21, "duplicate features detected"
    print(f"OK — {len(ALL_FEATURES)} unique features total.")