"""Shared setup for the Week 10 follow-up experiments.

Every experiment script imports this first. It finds the project root from its own
location, so the scripts run from anywhere without editing paths, and it builds the
model factories in one place so all experiments compare exactly the same models.
"""

import sys, json
from pathlib import Path

# src/common.py -> parents[1] is the project root
ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
RESULTS.mkdir(exist_ok=True)
RAW = ROOT / 'datasets' / 'brfss_raw.csv'

sys.path.insert(0, str(ROOT))                 # so "from src...." finds the classifiers
sys.path.insert(0, str(ROOT / 'src'))         # so "from deep_net...." finds the new code

import numpy as np
import pandas as pd

from src.feature_groups import ALL_FEATURES, CONTINUOUS_FEATURES
from src.naive_bayes import NaiveBayesClassifier
from src.decision_tree import DecisionTreeClassifier
from deep_net import DeepNeuralNetwork


def _load_hyperparams():
    """Reuse the hyperparameters already chosen in Weeks 5 and 7, never re-tune here."""
    mnn = json.load(open(ROOT / 'results' / 'week7_mnn_results.json'))['mnn_hyperparams']
    dt = json.load(open(ROOT / 'results' / 'dt_incremental_results.json'))['hyperparams']
    return mnn, dt


HP, DT_HP = _load_hyperparams()


def build_balanced(n_per_class=None, seed=42):
    """Balanced sample drawn from the full 253,680 real survey rows.

    n_per_class=5000 reproduces the Week 7 dataset size.
    n_per_class=None uses every positive case, giving about 47,786 rows -- the
    largest balanced sample the data allows.
    """
    raw = pd.read_csv(RAW)
    y_all = raw['HeartDiseaseorAttack'].astype(int)
    X_all = raw[ALL_FEATURES].astype(float)
    pos = np.where(y_all == 1)[0]
    neg = np.where(y_all == 0)[0]
    rng = np.random.default_rng(seed)
    rng.shuffle(pos); rng.shuffle(neg)
    k = len(pos) if n_per_class is None else min(n_per_class, len(pos))
    idx = np.concatenate([pos[:k], neg[:k]])
    rng.shuffle(idx)
    return X_all.iloc[idx].reset_index(drop=True), y_all.iloc[idx].reset_index(drop=True)


def load_full(seed=42):
    """The whole survey at its natural 9.4% rate, shuffled once."""
    raw = pd.read_csv(RAW).sample(frac=1.0, random_state=seed).reset_index(drop=True)
    return raw[ALL_FEATURES].astype(float), raw['HeartDiseaseorAttack'].astype(int)


def net(hidden_layers):
    """A network of the given depth. Every depth shares one training procedure."""
    return DeepNeuralNetwork(hidden_layers=hidden_layers,
                             learning_rate=HP['learning_rate'],
                             batch_size=HP['batch_size'],
                             momentum=HP['momentum'], seed=42)


def make_factories():
    """All models under comparison. hidden_layers=() is a logistic regression."""
    return {
        'NB': lambda: NaiveBayesClassifier(continuous_features=CONTINUOUS_FEATURES, alpha=1.0),
        'DT': lambda: DecisionTreeClassifier(continuous_features=CONTINUOUS_FEATURES,
                                             max_depth=DT_HP['max_depth'],
                                             min_samples_leaf=DT_HP['min_samples_leaf']),
        'LR (0 hidden)':   lambda: net(()),
        'MNN (1 hidden)':  lambda: net((HP['hidden_units'],)),
        'Deep (2 hidden)': lambda: net((16, 8)),
        'Deep (3 hidden)': lambda: net((32, 16, 8)),
    }


DEPTH_LADDER = [
    ('LR (0 hidden)',   ()),
    ('MNN (1 hidden)',  (HP['hidden_units'],)),
    ('Deep (2 hidden)', (16, 8)),
    ('Deep (3 hidden)', (32, 16, 8)),
]


def save_rows(rows, filename, append=False):
    """Write results to results/<filename>.

    Overwrites by default. Re-running a whole experiment then replaces its old
    output instead of silently doubling it, which would corrupt the figures.
    Pass append=True only when deliberately running one arm at a time.
    """
    p = RESULTS / filename
    old = json.load(open(p)) if (append and p.exists()) else []
    json.dump(old + rows, open(p, 'w'), indent=2, default=float)
    return len(old) + len(rows)


def save_obj(obj, filename):
    """Write a single object (not a list of rows) to results/<filename>."""
    json.dump(obj, open(RESULTS / filename, 'w'), indent=2, default=float)
    return filename


def corrected_paired_test(a, b, n_test, n_train):
    """Nadeau-Bengio corrected resampled t-test.

    Cross-validation folds share training data, so the paired scores are not
    independent and an ordinary paired t-test understates the variance. The
    correction replaces the 1/J variance term with 1/J + n_test/n_train.

    Returns (mean difference, uncorrected p, corrected p).
    """
    import numpy as _np
    from scipy import stats as _st
    a, b = _np.asarray(a, dtype=float), _np.asarray(b, dtype=float)
    d = a - b
    J = len(d)
    _, p_uncorrected = _st.ttest_rel(a, b)
    var = d.var(ddof=1)
    if var == 0:
        return float(d.mean()), float(p_uncorrected), 1.0
    t = d.mean() / _np.sqrt((1.0 / J + n_test / n_train) * var)
    p_corrected = 2 * (1 - _st.t.cdf(abs(t), df=J - 1))
    return float(d.mean()), float(p_uncorrected), float(p_corrected)
