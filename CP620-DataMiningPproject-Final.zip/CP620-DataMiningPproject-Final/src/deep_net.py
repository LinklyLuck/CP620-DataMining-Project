"""Feed-forward network with any number of hidden layers.

Why this file exists, on top of neural_net.py:
  Week 7 showed the MNN only wins by a small margin. Two explanations were raised:
  the network may be too shallow, or the sample may be too small. To test depth
  fairly, every depth must share ONE training procedure -- same standardisation,
  same momentum, same early stopping -- so that depth is the ONLY thing changing.

  hidden_layers=()      ->  logistic regression   (input -> sigmoid output)
  hidden_layers=(16,)   ->  the Week 7 MNN        (one hidden layer)
  hidden_layers=(16,8)  ->  a deeper network      (two hidden layers)

neural_net.py is left untouched so its verified gradient check still stands.
"""

import numpy as np


def sigmoid(z):
    """Numerically stable sigmoid, split by sign so exp never overflows."""
    out = np.empty_like(z, dtype=float)
    pos = z >= 0                                     # for z>=0 use 1/(1+e^-z)
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])                             # for z<0 use e^z/(1+e^z)
    out[~pos] = ez / (1.0 + ez)
    return out


def sigmoid_derivative_from_activation(a):
    """Sigmoid derivative written from the activation: a(1-a)."""
    return a * (1.0 - a)


def binary_cross_entropy(y_true, y_pred, eps=1e-12):
    """Mean binary cross-entropy, clipped so log(0) can never happen."""
    p = np.clip(y_pred, eps, 1.0 - eps)
    return float(-np.mean(y_true * np.log(p) + (1 - y_true) * np.log(1 - p)))


class DeepNeuralNetwork:
    """Sigmoid feed-forward net trained by mini-batch SGD with momentum.

    Same interface as the Week 7 MNN (fit / predict / predict_proba / classes_)
    so analysis.py can run it without any change.
    """

    def __init__(self, hidden_layers=(16,), learning_rate=0.1, momentum=0.9,
                 batch_size=16, max_epochs=200, early_stopping_patience=10,
                 validation_fraction=0.1, seed=42, lr_decay=0.01):
        self.hidden_layers = tuple(hidden_layers)    # () means logistic regression
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.early_stopping_patience = early_stopping_patience
        self.validation_fraction = validation_fraction
        self.seed = seed
        self.lr_decay = lr_decay

        self.weights_ = None          # list of weight matrices, one per layer
        self.biases_ = None           # list of bias vectors, one per layer
        self.mean_ = None             # training-fold mean, for standardising
        self.std_ = None              # training-fold std
        self.classes_ = np.array([0, 1])
        self.loss_curve_ = []         # training loss per epoch
        self.val_curve_ = []          # validation loss per epoch
        self.n_epochs_ = 0            # epochs actually used before early stop
        self.best_val_loss_ = None
        self._rng = None

    # ---------- standardisation ----------

    def _standardize_fit(self, X):
        """Learn mean/std from the training fold only, never from test data."""
        self.mean_ = X.mean(axis=0)
        self.std_ = X.std(axis=0)
        binary = np.all((X == 0) | (X == 1), axis=0)   # leave 0/1 columns alone
        self.mean_[binary] = 0.0
        self.std_[binary] = 1.0
        self.std_[self.std_ == 0] = 1.0                # constant column -> std 1
        return (X - self.mean_) / self.std_

    def _standardize_transform(self, X):
        """Apply the stored training-fold statistics."""
        return (X - self.mean_) / self.std_

    # ---------- initialisation ----------

    def _init_weights(self, n_features):
        """Uniform init scaled by fan-in, same rule as the Week 7 network."""
        sizes = [n_features] + list(self.hidden_layers) + [1]   # full layer plan
        self.weights_, self.biases_ = [], []
        for i in range(len(sizes) - 1):
            limit = 0.5 / np.sqrt(sizes[i])                     # keeps early nets small
            self.weights_.append(self._rng.uniform(-limit, limit,
                                                   size=(sizes[i], sizes[i + 1])))
            self.biases_.append(np.zeros(sizes[i + 1]))         # biases start at 0

    # ---------- forward / backward ----------

    def _forward(self, X_std):
        """Run the net forward, returning the activation of every layer."""
        acts = [X_std]                                  # acts[0] is the input
        a = X_std
        for W, b in zip(self.weights_, self.biases_):
            a = sigmoid(a @ W + b)                      # sigmoid on every layer
            acts.append(a)
        return acts                                     # last entry is the output

    def _backward(self, acts, y):
        """Backpropagate through any number of layers."""
        n = len(y)
        y_col = y.reshape(-1, 1)
        # Output layer: sigmoid and cross-entropy cancel, so delta is just error/n
        delta = (acts[-1] - y_col) / n
        grads_W = [None] * len(self.weights_)
        grads_b = [None] * len(self.biases_)
        for l in range(len(self.weights_) - 1, -1, -1):
            grads_W[l] = acts[l].T @ delta              # gradient for this layer
            grads_b[l] = delta.sum(axis=0)
            if l > 0:                                   # push the error back one layer
                delta = (delta @ self.weights_[l].T) * \
                        sigmoid_derivative_from_activation(acts[l])
        return grads_W, grads_b

    # ---------- validation split ----------

    def _val_split(self, y01):
        """Stratified slice held out for early stopping."""
        idx_pos = np.where(y01 == 1)[0]
        idx_neg = np.where(y01 == 0)[0]
        self._rng.shuffle(idx_pos)
        self._rng.shuffle(idx_neg)
        n_pos = max(1, int(len(idx_pos) * self.validation_fraction))
        n_neg = max(1, int(len(idx_neg) * self.validation_fraction))
        val = np.concatenate([idx_pos[:n_pos], idx_neg[:n_neg]])
        train = np.concatenate([idx_pos[n_pos:], idx_neg[n_neg:]])
        self._rng.shuffle(val)
        self._rng.shuffle(train)
        return train, val

    # ---------- fit ----------

    def fit(self, X, y):
        """Train with mini-batch SGD, momentum, lr decay and early stopping."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).ravel()
        self._rng = np.random.default_rng(self.seed)

        X_std = self._standardize_fit(X)
        self._init_weights(X_std.shape[1])

        tr, va = self._val_split(y)
        Xtr, ytr, Xva, yva = X_std[tr], y[tr], X_std[va], y[va]

        # momentum buffers, one per weight matrix and bias vector
        vel_W = [np.zeros_like(W) for W in self.weights_]
        vel_b = [np.zeros_like(b) for b in self.biases_]

        best_val, best_state, patience = np.inf, None, 0
        self.loss_curve_, self.val_curve_ = [], []

        for epoch in range(self.max_epochs):
            lr = self.learning_rate / (1.0 + self.lr_decay * epoch)   # decay the step
            order = self._rng.permutation(len(ytr))                   # reshuffle each epoch

            for start in range(0, len(order), self.batch_size):
                b = order[start:start + self.batch_size]              # one mini-batch
                acts = self._forward(Xtr[b])
                gW, gb = self._backward(acts, ytr[b])
                for l in range(len(self.weights_)):
                    vel_W[l] = self.momentum * vel_W[l] - lr * gW[l]  # momentum update
                    vel_b[l] = self.momentum * vel_b[l] - lr * gb[l]
                    self.weights_[l] += vel_W[l]
                    self.biases_[l] += vel_b[l]

            tr_loss = binary_cross_entropy(ytr, self._forward(Xtr)[-1].ravel())
            va_loss = binary_cross_entropy(yva, self._forward(Xva)[-1].ravel())
            self.loss_curve_.append(tr_loss)
            self.val_curve_.append(va_loss)

            if va_loss < best_val - 1e-6:               # improved -> remember this net
                best_val = va_loss
                best_state = ([W.copy() for W in self.weights_],
                              [b.copy() for b in self.biases_])
                patience = 0
            else:
                patience += 1
                if patience >= self.early_stopping_patience:
                    break                               # stop, we are not improving

        self.n_epochs_ = len(self.loss_curve_)
        if best_state is not None:                      # roll back to the best epoch
            self.weights_, self.biases_ = best_state
        self.best_val_loss_ = best_val
        return self

    # ---------- predict ----------

    def predict_proba(self, X):
        """Return P(y=0), P(y=1) in two columns, like sklearn does."""
        X_std = self._standardize_transform(np.asarray(X, dtype=float))
        p1 = self._forward(X_std)[-1].ravel()
        return np.column_stack([1.0 - p1, p1])

    def predict(self, X):
        """Hard 0/1 prediction at the usual 0.5 threshold."""
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)

    def n_params(self, n_features=None):
        """Count every weight and bias. Works before fitting if n_features is given."""
        if self.weights_ is not None:                        # already trained
            return int(sum(W.size for W in self.weights_) +
                       sum(b.size for b in self.biases_))
        if n_features is None:
            return None                                      # cannot know yet
        sizes = [n_features] + list(self.hidden_layers) + [1]
        return int(sum(sizes[i] * sizes[i + 1] + sizes[i + 1]
                       for i in range(len(sizes) - 1)))

    def describe(self):
        """Short human-readable name used in tables and plots."""
        if not self.hidden_layers:
            return "0 hidden (logistic regression)"
        return f"{len(self.hidden_layers)} hidden {list(self.hidden_layers)}"

    def __repr__(self):
        return (f'DeepNeuralNetwork(hidden_layers={self.hidden_layers}, '
                f'lr={self.learning_rate}, batch={self.batch_size})')


def numerical_gradient_check_deep(hidden_layers, X, y, epsilon=1e-4, seed=0):
    """Check backprop for a given depth against central finite differences.

    The new backward pass loops over layers, so it must be verified separately
    from the Week 7 one-layer version. A small net is used on purpose: finite
    differences need two forward passes per parameter, and correctness of
    backpropagation does not depend on the size of the network.

    Note on epsilon: 1e-4 is used, not the 1e-5 of the one-layer check. With two
    stacked sigmoids some gradients fall to about 1e-6, and a central difference
    of two losses that differ in the 14th decimal loses most of its precision --
    the relative error then reports float noise, not a backprop error. Raising
    epsilon lifts the difference above the noise floor; the measured error drops
    by roughly 20x, which is the signature of cancellation rather than a bug.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).ravel()

    net = DeepNeuralNetwork(hidden_layers=hidden_layers, seed=seed)
    net._rng = np.random.default_rng(seed)
    X_std = net._standardize_fit(X)
    net._init_weights(X_std.shape[1])

    acts = net._forward(X_std)                       # analytical gradients
    gW, gb = net._backward(acts, y)

    def loss_now():
        return binary_cross_entropy(y, net._forward(X_std)[-1].ravel())

    max_rel, n_checked = 0.0, 0
    for l in range(len(net.weights_)):
        for arr, grad in ((net.weights_[l], gW[l]), (net.biases_[l], gb[l])):
            it = np.nditer(arr, flags=['multi_index'])
            while not it.finished:
                i = it.multi_index
                original = arr[i]
                arr[i] = original + epsilon           # nudge up
                loss_up = loss_now()
                arr[i] = original - epsilon           # nudge down
                loss_dn = loss_now()
                arr[i] = original                     # always put it back
                numeric = (loss_up - loss_dn) / (2 * epsilon)
                analytic = grad[i]
                denom = max(1e-12, abs(numeric) + abs(analytic))
                max_rel = max(max_rel, abs(numeric - analytic) / denom)
                n_checked += 1
                it.iternext()
    return {'max_relative_error': max_rel, 'n_params_checked': n_checked,
            'hidden_layers': tuple(hidden_layers)}


if __name__ == '__main__':
    # Smoke test: verify backprop at three depths, including 0 hidden layers
    rng = np.random.default_rng(0)
    Xd = rng.normal(size=(40, 5))
    yd = (rng.random(40) < 0.5).astype(float)
    for hl in [(), (5,), (5, 4)]:
        r = numerical_gradient_check_deep(hl, Xd, yd)
        tag = 'PASS' if r['max_relative_error'] < 1e-6 else 'FAIL'
        print(f"hidden_layers={str(hl):10s} params={r['n_params_checked']:3d} "
              f"max rel err={r['max_relative_error']:.2e}  {tag}")
