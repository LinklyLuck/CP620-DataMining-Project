import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, average_precision_score,
                             confusion_matrix, precision_recall_curve, roc_curve)


# Shared plumbing

def make_folds(y, n_splits=5, seed=42):
    """Same stratified folds as src.data_loader.stratified_folds (seed 42)."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(skf.split(np.zeros(len(y)), y))


def _scores(clf, X_test):
    """Get hard labels and P(y=1) out of any fitted classifier."""
    pred = clf.predict(X_test)
    proba = clf.predict_proba(X_test)[:, list(clf.classes_).index(1)]
    return pred, proba


def _metric_pack(y_true, pred, proba):
    """The Lecture-8 metric battery plus AUC and AP for one fold."""
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        'accuracy':  accuracy_score(y_true, pred),
        'precision': precision_score(y_true, pred, zero_division=0),
        'recall':    recall_score(y_true, pred, zero_division=0),
        'f1':        f1_score(y_true, pred, zero_division=0),
        'fpr':       fp / (fp + tn) if (fp + tn) > 0 else 0.0,   # false-positive rate
        'auc':       roc_auc_score(y_true, proba),
        'ap':        average_precision_score(y_true, proba),
    }


def cross_validate(X, y, clf_factory, features=None, folds=None,
                   n_splits=5, seed=42, return_folds=False):
    """Stratified k-fold CV. Returns {metric: (mean, std)} across folds."""
    X = pd.DataFrame(X).reset_index(drop=True)
    y = pd.Series(y).reset_index(drop=True)
    if features is not None:
        X = X[list(features)].copy()
    if folds is None:
        folds = make_folds(y, n_splits, seed)

    per_fold = []
    for tr, te in folds:
        clf = clf_factory()
        clf.fit(X.iloc[tr], y.iloc[tr])
        pred, proba = _scores(clf, X.iloc[te])
        per_fold.append(_metric_pack(y.iloc[te], pred, proba))

    summary = {m: (float(np.mean([f[m] for f in per_fold])),
                   float(np.std([f[m] for f in per_fold])))
               for m in per_fold[0]}
    return (summary, per_fold) if return_folds else summary



# 1. Incremental (5-by-5) feature feeding — kept from Weeks 3/5

def incremental_feature_experiment(X, y, clf_factory, subsets, labels,
                                   folds=None, n_splits=5, seed=42):
    """Run CV once per cumulative feature subset. Returns {label: summary}."""
    if folds is None:
        folds = make_folds(y, n_splits, seed)
    out = {}
    for label, subset in zip(labels, subsets):
        out[label] = cross_validate(X, y, clf_factory, features=subset, folds=folds)
    return out



# 2. Leave-one-group-out — how much does each feature GROUP add on its own?

def leave_one_group_out(X, y, clf_factory, feature_groups, all_features,
                        folds=None, n_splits=5, seed=42):
    """
    Train on all features, then retrain with one whole group removed each time.

    Incremental feeding adds groups in a fixed order, so a group that arrives
    late can look useless just because an earlier group already covers it.
    Dropping one group from the FULL set measures what only that group provides.

    Returns a DataFrame with the drop in each metric (bigger drop = more useful).
    """
    if folds is None:
        folds = make_folds(y, n_splits, seed)

    base = cross_validate(X, y, clf_factory, features=all_features, folds=folds)

    rows = [{'removed_group': '(none) all features',
             'n_features': len(all_features),
             'f1': base['f1'][0], 'auc': base['auc'][0],
             'f1_drop': 0.0, 'auc_drop': 0.0}]

    for gname, gfeats in feature_groups.items():
        kept = [f for f in all_features if f not in gfeats]   # drop the whole group
        if len(kept) == 0:
            continue
        res = cross_validate(X, y, clf_factory, features=kept, folds=folds)
        rows.append({'removed_group': gname,
                     'n_features': len(kept),
                     'f1': res['f1'][0], 'auc': res['auc'][0],
                     'f1_drop': base['f1'][0] - res['f1'][0],
                     'auc_drop': base['auc'][0] - res['auc'][0]})

    return pd.DataFrame(rows)



# 3. Permutation importance — which single features does the model lean on?

def permutation_importance(X, y, clf_factory, features, n_repeats=3,
                           folds=None, n_splits=5, seed=42):
    """
    Shuffle one feature column in the TEST fold and see how much F1 / AUC falls.

    Shuffling keeps the column's marginal distribution but destroys its link to
    the label, so a big drop means the model really used that feature.

    Returns a DataFrame sorted by mean F1 drop (most important first).
    """
    X = pd.DataFrame(X).reset_index(drop=True)[list(features)]
    y = pd.Series(y).reset_index(drop=True)
    if folds is None:
        folds = make_folds(y, n_splits, seed)

    drops_f1 = {f: [] for f in features}
    drops_auc = {f: [] for f in features}

    for k, (tr, te) in enumerate(folds):
        clf = clf_factory()
        clf.fit(X.iloc[tr], y.iloc[tr])
        X_te, y_te = X.iloc[te].reset_index(drop=True), y.iloc[te].reset_index(drop=True)

        pred, proba = _scores(clf, X_te)                       # untouched baseline
        base_f1 = f1_score(y_te, pred, zero_division=0)
        base_auc = roc_auc_score(y_te, proba)

        for f in features:
            for r in range(n_repeats):
                rng = np.random.default_rng(seed + 1000 * k + 10 * r)
                X_perm = X_te.copy()
                X_perm[f] = rng.permutation(X_perm[f].to_numpy())   # break this column only
                p_pred, p_proba = _scores(clf, X_perm)
                drops_f1[f].append(base_f1 - f1_score(y_te, p_pred, zero_division=0))
                drops_auc[f].append(base_auc - roc_auc_score(y_te, p_proba))

    rows = [{'feature': f,
             'f1_drop': float(np.mean(drops_f1[f])),
             'f1_drop_std': float(np.std(drops_f1[f])),
             'auc_drop': float(np.mean(drops_auc[f])),
             'auc_drop_std': float(np.std(drops_auc[f]))}
            for f in features]
    return pd.DataFrame(rows).sort_values('f1_drop', ascending=False).reset_index(drop=True)



# 4. Single-feature ranking — how strong is each feature completely on its own?

def single_feature_ranking(X, y, clf_factory, features, folds=None,
                           n_splits=5, seed=42):
    """
    Train the classifier on ONE feature at a time and rank by AUC.

    This is the opposite view to permutation importance: permutation asks
    "what happens if I take this feature away from the full model", this asks
    "how far does this feature get on its own". A feature can score high here
    and low there when it is redundant with another feature.
    """
    if folds is None:
        folds = make_folds(y, n_splits, seed)
    rows = []
    for f in features:
        res = cross_validate(X, y, clf_factory, features=[f], folds=folds)
        rows.append({'feature': f,
                     'auc': res['auc'][0], 'auc_std': res['auc'][1],
                     'f1': res['f1'][0], 'accuracy': res['accuracy'][0]})
    return pd.DataFrame(rows).sort_values('auc', ascending=False).reset_index(drop=True)



# 5. Imbalanced regime — pooled out-of-fold scores for PR curves and AP

def pooled_oof_scores(X, y, clf_factory, features=None, folds=None,
                      n_splits=5, seed=42):
    """
    Collect out-of-fold P(y=1) for every row, so PR / ROC curves use all data once.

    Returns (y_true_pooled, proba_pooled, per_fold_metrics).
    """
    X = pd.DataFrame(X).reset_index(drop=True)
    y = pd.Series(y).reset_index(drop=True)
    if features is not None:
        X = X[list(features)].copy()
    if folds is None:
        folds = make_folds(y, n_splits, seed)

    proba_all = np.zeros(len(y))
    per_fold = []
    for tr, te in folds:
        clf = clf_factory()
        clf.fit(X.iloc[tr], y.iloc[tr])
        pred, proba = _scores(clf, X.iloc[te])
        proba_all[te] = proba                       # each row is predicted exactly once
        per_fold.append(_metric_pack(y.iloc[te], pred, proba))
    return y.to_numpy(), proba_all, per_fold


def best_f1_threshold(y_true, proba):
    """
    Sweep the decision threshold and return the one with the highest F1.

    Under heavy imbalance the default 0.5 cut is usually far too strict, so this
    shows how much of the "bad" F1 is the classifier and how much is the threshold.
    """
    prec, rec, thr = precision_recall_curve(y_true, proba)
    f1 = np.divide(2 * prec * rec, prec + rec,
                   out=np.zeros_like(prec), where=(prec + rec) > 0)
    best = int(np.argmax(f1[:-1]))                  # last point has no threshold
    return float(thr[best]), float(f1[best]), float(prec[best]), float(rec[best])


def majority_baseline(y_true):
    """All-negative baseline: high accuracy, zero positive-class F1."""
    pred = np.zeros(len(y_true), dtype=int)
    return {'accuracy': accuracy_score(y_true, pred),
            'f1': f1_score(y_true, pred, zero_division=0),
            'ap_no_skill': float(np.mean(y_true))}   # AP of a random ranker = prevalence



# Plot helpers

def plot_pr_curves(curves, positive_rate, ax=None, title='Precision-Recall curves'):
    """curves: list of (name, y_true, proba)."""
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(6.5, 5))
    for name, y_true, proba in curves:
        prec, rec, _ = precision_recall_curve(y_true, proba)
        ap = average_precision_score(y_true, proba)
        ax.plot(rec, prec, linewidth=2, label=f'{name} (AP={ap:.3f})')
    ax.axhline(positive_rate, color='grey', linestyle='--',
               label=f'no-skill (AP={positive_rate:.3f})')     # random ranking baseline
    ax.set_xlabel('Recall'); ax.set_ylabel('Precision')
    ax.set_title(title); ax.legend(loc='upper right'); ax.grid(alpha=0.3)
    return ax


def plot_roc_curves(curves, ax=None, title='ROC curves'):
    """curves: list of (name, y_true, proba)."""
    import matplotlib.pyplot as plt
    if ax is None:
        _, ax = plt.subplots(figsize=(6.5, 5))
    for name, y_true, proba in curves:
        fpr, tpr, _ = roc_curve(y_true, proba)
        ax.plot(fpr, tpr, linewidth=2,
                label=f'{name} (AUC={roc_auc_score(y_true, proba):.3f})')
    ax.plot([0, 1], [0, 1], color='grey', linestyle='--', label='chance')
    ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
    ax.set_title(title); ax.legend(loc='lower right'); ax.grid(alpha=0.3)
    return ax


def plot_importance_bars(tables, metric='f1_drop', top_n=12, title=None):
    """tables: dict of model name -> permutation-importance DataFrame."""
    import matplotlib.pyplot as plt
    names = list(tables.keys())
    # order the y axis by the first model's ranking so all panels line up
    order = list(tables[names[0]].sort_values(metric, ascending=False)['feature'])[:top_n]
    fig, axes = plt.subplots(1, len(names), figsize=(5 * len(names), 0.42 * top_n + 1.8),
                             sharey=True)
    axes = np.atleast_1d(axes)
    for ax, name in zip(axes, names):
        t = tables[name].set_index('feature').reindex(order)
        ax.barh(range(len(order)), t[metric].to_numpy())
        ax.set_yticks(range(len(order)))
        ax.set_yticklabels(order, fontsize=9)
        ax.invert_yaxis()                                  # most important on top
        ax.axvline(0, color='black', linewidth=0.8)
        ax.set_xlabel(metric.replace('_', ' '))
        ax.set_title(name)
        ax.grid(alpha=0.3, axis='x')
    fig.suptitle(title or f'Permutation importance ({metric})', y=1.02)
    fig.tight_layout()
    return fig
