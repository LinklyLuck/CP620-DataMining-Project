import numpy as np
import pandas as pd
from collections import Counter


# Entropy and information gain
def _entropy(y):
    """Shannon entropy of label distribution. Returns 0 for empty input."""
    n = len(y)
    if n == 0:
        return 0.0
    counts = np.bincount(y) if y.dtype.kind in 'iub' else \
             np.array(list(Counter(y).values()))
    probs = counts[counts > 0] / n
    return -np.sum(probs * np.log2(probs))


def _info_gain(y_parent, y_children):
    """Information gain = H(parent) - weighted sum of H(child)."""
    n = len(y_parent)
    if n == 0:
        return 0.0
    h_parent = _entropy(y_parent)
    h_weighted = sum(len(y_c) / n * _entropy(y_c) for y_c in y_children if len(y_c) > 0)
    return h_parent - h_weighted



# Tree node
class _Node:
    """One node of the decision tree. """
    __slots__ = ('is_leaf', 'class_counts', 'feature', 'split_type',
                 'threshold', 'children', 'majority')

    def __init__(self):
        self.is_leaf = False
        self.class_counts = None
        self.feature = None
        self.split_type = None
        self.threshold = None
        self.children = None
        self.majority = None



# Decision tree classifier
class DecisionTreeClassifier:
    """
    Decision Tree with mixed continuous/categorical splits."""

    def __init__(self, continuous_features=None, max_depth=None,
                 min_samples_leaf=5, min_info_gain=1e-6):
        self.continuous_features = set(continuous_features or [])
        self.max_depth = max_depth if max_depth is not None else float('inf')
        self.min_samples_leaf = min_samples_leaf
        self.min_info_gain = min_info_gain

        self.classes_ = None
        self.root_ = None
        self.feature_names_ = None

    def fit(self, X, y):
        X = pd.DataFrame(X).reset_index(drop=True)
        y = np.asarray(y).astype(int)
        self.feature_names_ = list(X.columns)
        self.classes_ = np.array(sorted(np.unique(y)))
        self.root_ = self._build(X, y, depth=0)
        return self

    # Tree construction
    def _build(self, X, y, depth):
        node = _Node()
        node.class_counts = Counter(y)
        node.majority = max(node.class_counts, key=node.class_counts.get)

        # Stopping conditions for pre-pruning
        if (depth >= self.max_depth or
                len(y) < 2 * self.min_samples_leaf or
                len(np.unique(y)) == 1):
            node.is_leaf = True
            return node

        best = self._find_best_split(X, y)
        if best is None or best['gain'] < self.min_info_gain:
            node.is_leaf = True
            return node

        # Apply the split
        node.feature = best['feature']
        node.split_type = best['split_type']

        if best['split_type'] == 'continuous':
            node.threshold = best['threshold']
            left_mask = X[node.feature] <= node.threshold
            node.children = (
                self._build(X[left_mask], y[left_mask.values], depth + 1),
                self._build(X[~left_mask], y[~left_mask.values], depth + 1),
            )
        else:
            node.children = {}
            for val, mask in best['masks'].items():
                node.children[val] = self._build(X[mask], y[mask.values], depth + 1)

        return node

    # Split search
    def _find_best_split(self, X, y):
        best = None
        for feat in self.feature_names_:
            if feat in self.continuous_features:
                cand = self._best_continuous_split(X[feat], y)
            else:
                cand = self._best_categorical_split(X[feat], y)
            if cand is None:
                continue
            cand['feature'] = feat
            if best is None or cand['gain'] > best['gain']:
                best = cand
        return best

    def _best_continuous_split(self, col, y):
        """Sweep over sorted unique midpoints to find best threshold."""
        sorted_vals = np.sort(col.unique())
        if len(sorted_vals) < 2:
            return None

        best_gain = -1.0
        best_thresh = None
        for i in range(len(sorted_vals) - 1):
            thresh = (sorted_vals[i] + sorted_vals[i + 1]) / 2
            left_mask = col <= thresh
            n_left = left_mask.sum()
            n_right = len(col) - n_left
            if n_left < self.min_samples_leaf or n_right < self.min_samples_leaf:
                continue
            gain = _info_gain(y, [y[left_mask.values], y[~left_mask.values]])
            if gain > best_gain:
                best_gain = gain
                best_thresh = thresh

        if best_thresh is None:
            return None
        return {'split_type': 'continuous', 'threshold': best_thresh, 'gain': best_gain}

    def _best_categorical_split(self, col, y):
        """Multi-way split: one child per unique value of the feature."""
        unique_vals = col.unique()
        if len(unique_vals) < 2:
            return None

        masks = {}
        children_y = []
        for v in unique_vals:
            mask = (col == v)
            if mask.sum() < self.min_samples_leaf:
                # If any branch is too small, reject this categorical split
                return None
            masks[v] = mask
            children_y.append(y[mask.values])

        gain = _info_gain(y, children_y)
        return {'split_type': 'categorical', 'masks': masks, 'gain': gain}

    # Prediction
    def _traverse(self, x_row, node):
        if node.is_leaf:
            return node
        if node.split_type == 'continuous':
            child = node.children[0] if x_row[node.feature] <= node.threshold else node.children[1]
            return self._traverse(x_row, child)
        else:
            val = x_row[node.feature]
            if val in node.children:
                return self._traverse(x_row, node.children[val])
            # Unseen categorical value at test time -> stop at current node
            return node

    def predict_proba(self, X):
        """Return normalised leaf-frequency probabilities, shape (n, n_classes)."""
        X = pd.DataFrame(X).reset_index(drop=True)
        out = np.zeros((len(X), len(self.classes_)))
        for i in range(len(X)):
            leaf = self._traverse(X.iloc[i], self.root_)
            total = sum(leaf.class_counts.values())
            for j, c in enumerate(self.classes_):
                out[i, j] = leaf.class_counts.get(int(c), 0) / total
        return out

    def predict(self, X):
        proba = self.predict_proba(X)
        return self.classes_[proba.argmax(axis=1)]
    
    # Diagnostics
    def depth(self):
        def _d(n, cur):
            if n.is_leaf:
                return cur
            kids = n.children if isinstance(n.children, tuple) else n.children.values()
            return max(_d(k, cur + 1) for k in kids)
        return _d(self.root_, 0)

    def n_leaves(self):
        def _c(n):
            if n.is_leaf:
                return 1
            kids = n.children if isinstance(n.children, tuple) else n.children.values()
            return sum(_c(k) for k in kids)
        return _c(self.root_)



# Inner-CV hyperparameter selection helper
def select_dt_hyperparams(X, y, continuous_features, candidate_depths=(3, 5, 7, 10, None),
                          candidate_min_leaf=(5, 10, 20), n_inner_splits=3, seed=42):
    """
    Pick (max_depth, min_samples_leaf) by inner stratified 3-fold CV on F1.
    Returns the best (depth, min_leaf, best_f1).
    """
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import f1_score

    X = pd.DataFrame(X).reset_index(drop=True)
    y = np.asarray(y).astype(int)

    skf = StratifiedKFold(n_splits=n_inner_splits, shuffle=True, random_state=seed)
    folds = list(skf.split(np.zeros(len(y)), y))

    best = None
    for depth in candidate_depths:
        for min_leaf in candidate_min_leaf:
            f1s = []
            for tr, va in folds:
                dt = DecisionTreeClassifier(
                    continuous_features=continuous_features,
                    max_depth=depth, min_samples_leaf=min_leaf)
                dt.fit(X.iloc[tr], y[tr])
                pred = dt.predict(X.iloc[va])
                f1s.append(f1_score(y[va], pred, zero_division=0))
            mean_f1 = np.mean(f1s)
            if best is None or mean_f1 > best[2]:
                best = (depth, min_leaf, mean_f1)
    return best



# Standalone smoke test
if __name__ == '__main__':
    # Reproduce the buys_computer example from Lecture 7 as a sanity check
    data = pd.DataFrame([
        ('<=30',  'high',   'no',  'fair',      0),
        ('<=30',  'high',   'no',  'excellent', 0),
        ('30-40', 'high',   'no',  'fair',      1),
        ('>40',   'medium', 'no',  'fair',      1),
        ('>40',   'low',    'yes', 'fair',      1),
        ('>40',   'low',    'yes', 'excellent', 0),
        ('30-40', 'low',    'yes', 'excellent', 1),
        ('<=30',  'medium', 'no',  'fair',      0),
        ('<=30',  'low',    'yes', 'fair',      1),
        ('>40',   'medium', 'yes', 'fair',      1),
        ('<=30',  'medium', 'yes', 'excellent', 1),
        ('30-40', 'medium', 'no',  'excellent', 1),
        ('30-40', 'high',   'yes', 'fair',      1),
        ('>40',   'medium', 'no',  'excellent', 0),
    ], columns=['age', 'income', 'student', 'credit_rating', 'buys_computer'])

    X = data[['age', 'income', 'student', 'credit_rating']]
    y = data['buys_computer'].values

    # Use small min_leaf because of the tiny dataset
    dt = DecisionTreeClassifier(continuous_features=set(),
                                max_depth=None, min_samples_leaf=1)
    dt.fit(X, y)

    print(f"Tree depth:    {dt.depth()}")
    print(f"Tree leaves:   {dt.n_leaves()}")
    print(f"Training acc:  {(dt.predict(X) == y).mean():.3f}")

    # The C4.5 textbook answer for this dataset puts 'age' at the root
    print(f"Root split:    feature='{dt.root_.feature}' (expected: 'age')")