import numpy as np
import pandas as pd


class NaiveBayesClassifier:
    """ Naive Bayes with mixed categorical + Gaussian likelihoods."""

    def __init__(self, continuous_features=None, alpha=1.0, var_smoothing=1e-9):
        self.continuous_features = set(continuous_features or [])
        self.alpha = alpha
        self.var_smoothing = var_smoothing

        # Fitted parameters (set after .fit())
        self.classes_ = None        # array of class labels seen in training
        self.log_priors_ = None     # dict: class -> log P(Y=class)
        self.cat_log_likelihoods_ = None  # dict: (class, feature, value) -> log P(x|y)
        self.cat_default_log_ = None # dict: (class, feature) -> log prob for unseen values
        self.gauss_params_ = None   # dict: (class, feature) -> (mean, var)
        self.feature_names_ = None  # list of column names seen in fit

    def fit(self, X, y):
        """Fit the classifier."""
        X = pd.DataFrame(X).reset_index(drop=True)
        y = pd.Series(y).reset_index(drop=True)

        self.feature_names_ = list(X.columns)
        self.classes_ = np.array(sorted(y.unique()))
        n = len(y)

        # Class priors
        self.log_priors_ = {}
        for c in self.classes_:
            self.log_priors_[c] = np.log((y == c).sum() / n)

        #  Likelihood tables 
        self.cat_log_likelihoods_ = {}
        self.cat_default_log_ = {}
        self.gauss_params_ = {}

        for c in self.classes_:
            X_c = X[y == c]
            n_c = len(X_c)

            for feat in self.feature_names_:
                if feat in self.continuous_features:
                    # Gaussian likelihood 
                    mean = X_c[feat].mean()
                    var = X_c[feat].var(ddof=0) + self.var_smoothing
                    self.gauss_params_[(c, feat)] = (mean, var)
                else:
                    # Categorical likelihood with Laplace smoothing 
                    # Use the full training column to find vocabulary so test-time
                    # unseen values fall through to the default smoothing prob.
                    vocab = X[feat].unique()
                    counts = X_c[feat].value_counts().to_dict()
                    V = len(vocab)
                    denom = n_c + self.alpha * V

                    for v in vocab:
                        count_v = counts.get(v, 0)
                        prob = (count_v + self.alpha) / denom
                        self.cat_log_likelihoods_[(c, feat, v)] = np.log(prob)

                    # Default for values never seen in the entire training set
                    # (rare, but possible at test time)
                    self.cat_default_log_[(c, feat)] = np.log(self.alpha / denom)

        return self

    def _log_likelihood_single(self, x_row, c):
        """Compute log P(X=x | Y=c) for one row, summed across features."""
        total = self.log_priors_[c]
        for feat in self.feature_names_:
            val = x_row[feat]
            if feat in self.continuous_features:
                mean, var = self.gauss_params_[(c, feat)]
                # log of Gaussian pdf
                log_p = -0.5 * np.log(2 * np.pi * var) - 0.5 * ((val - mean) ** 2) / var
            else:
                key = (c, feat, val)
                log_p = self.cat_log_likelihoods_.get(key,
                        self.cat_default_log_[(c, feat)])
            total += log_p
        return total

    def predict_log_proba(self, X):
        """Return unnormalised log posteriors, shape (n, n_classes)."""
        X = pd.DataFrame(X).reset_index(drop=True)
        n = len(X)
        n_classes = len(self.classes_)
        log_probs = np.zeros((n, n_classes))
        for i in range(n):
            x_row = X.iloc[i]
            for j, c in enumerate(self.classes_):
                log_probs[i, j] = self._log_likelihood_single(x_row, c)
        return log_probs

    def predict_proba(self, X):
        """Return normalised posteriors P(Y=c | X), shape (n, n_classes)."""
        log_probs = self.predict_log_proba(X)
        # Log-sum-exp normalisation for numerical stability
        max_log = log_probs.max(axis=1, keepdims=True)
        log_probs_shifted = log_probs - max_log
        probs = np.exp(log_probs_shifted)
        probs /= probs.sum(axis=1, keepdims=True)
        return probs

    def predict(self, X):
        """Return predicted class label per row, shape (n,)."""
        log_probs = self.predict_log_proba(X)
        return self.classes_[log_probs.argmax(axis=1)]


# Standalone test: reproduce the buys_computer worked example from Lecture 7
if __name__ == '__main__':
    # Build the lecture's 14-row table
    data = pd.DataFrame([
        ('<=30',  'high',   'no',  'fair',      'no'),
        ('<=30',  'high',   'no',  'excellent', 'no'),
        ('30-40', 'high',   'no',  'fair',      'yes'),
        ('>40',   'medium', 'no',  'fair',      'yes'),
        ('>40',   'low',    'yes', 'fair',      'yes'),
        ('>40',   'low',    'yes', 'excellent', 'no'),
        ('30-40', 'low',    'yes', 'excellent', 'yes'),
        ('<=30',  'medium', 'no',  'fair',      'no'),
        ('<=30',  'low',    'yes', 'fair',      'yes'),
        ('>40',   'medium', 'yes', 'fair',      'yes'),
        ('<=30',  'medium', 'yes', 'excellent', 'yes'),
        ('30-40', 'medium', 'no',  'excellent', 'yes'),
        ('30-40', 'high',   'yes', 'fair',      'yes'),
        ('>40',   'medium', 'no',  'excellent', 'no'),
    ], columns=['age', 'income', 'student', 'credit_rating', 'buys_computer'])

    X = data[['age', 'income', 'student', 'credit_rating']]
    y = data['buys_computer']

    nb = NaiveBayesClassifier(continuous_features=set(), alpha=1.0)  # same smoothing as every experiment
    nb.fit(X, y)

    # Test the lecture query: X = (age<=30, income=medium, student=yes, credit=fair)
    query = pd.DataFrame([{
        'age': '<=30', 'income': 'medium', 'student': 'yes', 'credit_rating': 'fair'
    }])
    proba = nb.predict_proba(query)
    pred = nb.predict(query)
    print("Lecture 7 buys_computer worked example:")
    print(f"  P(yes|X) = {proba[0][list(nb.classes_).index('yes')]:.4f}")
    print(f"  P(no |X) = {proba[0][list(nb.classes_).index('no')]:.4f}")
    print(f"  Predicted: {pred[0]}")
    print(f"  Expected (from Lecture 7 slide): yes (P(X|yes)·P(yes) = 0.044 > P(X|no)·P(no) = 0.019)")