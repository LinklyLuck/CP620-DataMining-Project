"""Data loading and stratified-CV utilities for the BRFSS project."""

from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold

DATA_DIR = Path(__file__).resolve().parent.parent / 'datasets'

FILE_MAP = {
    'balanced':   DATA_DIR / 'heart_disease_balanced.csv',
    'imbalanced': DATA_DIR / 'heart_disease_clean.csv',
}


def load_dataset(name='balanced'):

    assert name in FILE_MAP, f"name must be one of {list(FILE_MAP.keys())}"
    df = pd.read_csv(FILE_MAP[name])
    y = df['target']
    X = df.drop('target', axis=1)
    return X, y


def get_feature_subset(X, feature_list):
    """Return X restricted to the given feature columns (copy)."""
    return X[feature_list].copy()


def stratified_folds(y, n_splits=5, seed=42):
    """Generator of (train_idx, test_idx) for stratified k-fold CV."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return skf.split(np.zeros(len(y)), y)


if __name__ == '__main__':
    for name in ['balanced', 'imbalanced']:
        X, y = load_dataset(name)
        print(f"\n[{name}] X={X.shape}, y={y.shape}")
        print(f"  class balance: {y.value_counts().to_dict()}")
        print(f"  positive rate: {y.mean():.2%}")

    X, y = load_dataset('balanced')
    print("\n[stratified 5-fold on balanced]")
    for i, (tr, te) in enumerate(stratified_folds(y)):
        pos_train = y.iloc[tr].mean()
        pos_test = y.iloc[te].mean()
        print(f"  fold {i}: train n={len(tr):4d} pos={pos_train:.1%}  "
              f"|  test n={len(te):4d} pos={pos_test:.1%}")