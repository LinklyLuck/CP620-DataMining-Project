# CP620 Data Mining Programming — Final Project

**Where Does the Ceiling Come From?**
A Comparative Study of Generative, Discriminative, and Tree-Based Classifiers
on the BRFSS Heart Disease Indicators Dataset

Andy An · Instructor: Prof. Lei Gao

The final report is `CP620_Final_Report.pdf` in this folder.

---

## 1. What this project does

Three classifiers are implemented **from scratch** with NumPy and compared under one shared
evaluation harness, so that only the classifier changes between runs:

| Model | Family | File |
|---|---|---|
| Naive Bayes | generative | `src/naive_bayes.py` |
| Decision Tree | tree-based | `src/decision_tree.py` |
| Multilayer Neural Network | discriminative | `src/neural_net.py` |

scikit-learn is used for fold splitting, metric computation, nearest-neighbour search in
the SMOTE extension (`src/synth_data.py`), and the logistic-regression reference baseline.
The three primary classifiers contain no scikit-learn.

**Note on the tuning protocol.** Decision-tree and neural-network hyperparameters are
selected once by inner 3-fold cross-validation on the training portion of the first 5-fold
split, then fixed for the reported comparison. This is a *partially nested* protocol, not
fully nested: because that training portion is the union of the other four test folds, four
of the five reported test folds contain rows that took part in hyperparameter selection. No
row is ever in the training set and the test set of the same fit, so this is not model-fit
leakage, but the estimates may be slightly optimistic.

The second half of the project asks why the neural network's lead is small, and runs seven
controlled experiments to test whether the limitation is network depth or sample size.

---

## 2. How to download

```bash
git clone https://github.com/LinklyLuck/CP620-DataMining-Project.git
cd CP620-DataMining-Project
```

Or download the ZIP from the same page and unzip it.

---

## 3. How to install

Python 3.9 or newer is required. There is nothing to compile; the project is pure Python.

```bash
pip install -r requirements.txt
```

That installs numpy, pandas, matplotlib, scikit-learn, scipy and jupyter.

To reproduce the reported numbers digit for digit, use the pinned versions instead:

```bash
pip install -r requirements-lock.txt
```

With unpinned versions a few results move in the third decimal place, because the networks
start from random weights and SMOTE's nearest-neighbour ties are resolved by scikit-learn's
internal sort. No conclusion changes.

To check the install worked:

```bash
python -c "from src.data_loader import load_dataset; from src import common; print('OK')"
```

---

## 4. How to get and use the data

**The data is already included** in `datasets/`. Nothing needs downloading to run the code.

The data originates from the Heart Disease Health Indicators Dataset, released on Kaggle by
Alex Teboul from cleaned CDC BRFSS 2015 survey data (licence: CC0 Public Domain).

- Cleaned release: https://www.kaggle.com/datasets/alexteboul/heart-disease-health-indicators-dataset
- Original survey: https://www.cdc.gov/brfss/annual_data/annual_2015.html

To download it yourself, get `heart_disease_health_indicators_BRFSS2015.csv` from the Kaggle
link and save it as `datasets/brfss_raw.csv`. Everything else is regenerated from it by:

```bash
python preprocess.py
```

That reproduces `heart_disease_balanced.csv` and `heart_disease_clean.csv` byte for byte.

**The two samples are not disjoint.** Both are drawn from the same source pools with the
same seed, and neither draw excludes the other, so 6,413 source rows appear in both: all
1,413 positives of the imbalanced sample, and all 5,000 negatives of the balanced sample.
`preprocess.py` measures and prints this overlap.

This does not create train/test leakage. The two samples are used in separate experiments,
and each experiment runs its own cross-validation inside its own sample, so no row is ever
in the training fold and the test fold of the same fit. It does mean the two experiments
are not independent samples of the population, so the imbalanced results should not be read
as an external validation of the balanced results.

### Files in `datasets/`

| File | Rows | Positive rate | What it is |
|---|---|---|---|
| `brfss_raw.csv` | 253,680 | 9.4% | The full cleaned survey. Everything derives from this. |
| `heart_disease_balanced.csv` | 10,000 | 50% | Primary balanced sample (Weeks 3–9) |
| `heart_disease_clean.csv` | 15,000 | 9.4% | Imbalanced sample, for the Precision-Recall study |
| `real_balanced_10000.csv` | 10,000 | 50% | Base sample for the follow-up experiments |
| `real_balanced_47786.csv` | 47,786 | 50% | Largest balanced sample possible; uses all 23,893 positives |
| `SYNTHETIC_smote_70000.csv` | 70,000 | 50% | **Contains synthetic rows** — see the warning below |
| `SYNTHETIC_bootstrap_70000.csv` | 70,000 | 50% | **Contains synthetic rows** — bootstrap control |

`datasets/DATASETS.md` documents all seven files in detail.

### Warning about the two synthetic files

The two files whose names begin with `SYNTHETIC_` contain rows that are **not real people**.
They were generated for one experiment: testing whether synthetic augmentation raises
performance. It does not.

Every row carries an `is_synthetic` column: `0` for real, `1` for generated.

**Never build the train/test split after augmenting.** Synthetic rows are interpolated from
real rows, so a split made afterwards puts a row and its interpolations on opposite sides.
This was measured: augmenting first and splitting after gives test folds that are roughly
86% synthetic and 14% original, and the neural network reads F1 = 0.8048 on them against
F1 = 0.7565 when scored on real held-out rows — an inflation larger than the entire effect
the project studies.

The correct order is: split the **real** data into train and test first, then augment
**only the training part**. Never build the split after augmenting, because the real rows
inside these files were used to generate the synthetic ones.

```python
from sklearn.model_selection import StratifiedKFold
from src.synth_data import smote_nc

# real data only
X, y = load_dataset("balanced")

for tr, te in StratifiedKFold(5, shuffle=True, random_state=42).split(X, y):
    X_tr, y_tr = smote_nc(X.iloc[tr], y.iloc[tr], 70000, seed=42)   # augment TRAIN only
    model.fit(X_tr, y_tr)
    score(model, X.iloc[te], y.iloc[te])                            # test stays REAL
```

The two `SYNTHETIC_*.csv` files are provided so the generated rows can be inspected. They
are a single standalone generation and cannot reproduce the reported numbers, because the
experiments regenerate synthetic rows inside each fold. Use `experiments/exp4_synthetic.py`
to reproduce the results.

---

## 5. How to run the code

All commands are run **from the project root**.

### 5.1 The notebooks (Weeks 3–9: the main comparison)

Open them in Jupyter and run all cells top to bottom:

```bash
jupyter notebook
```

Run in this order; each writes its results into `results/`:

| Notebook | What it produces |
|---|---|
| `notebooks/02_naive_bayes_presentation.ipynb` | Naive Bayes, incremental feature feeding |
| `notebooks/03_decision_tree_presentation.ipynb` | Decision tree, pruning selection |
| `notebooks/04_mnn_presentation.ipynb` | Neural network, gradient check, three-way comparison |
| `notebooks/05_feature_importance.ipynb` | Leave-one-group-out, permutation importance |
| `notebooks/06_ranking_and_imbalance.ipynb` | Single-feature ranking, imbalanced regime |

Two combined notebooks are also included. They contain no new work, only the same cells
gathered together for reading:

| Notebook | Contents |
|---|---|
| `notebooks/CP620_presentation.ipynb` | Notebooks 02 and 03 combined (the Week 5 progress talk) |
| `notebooks/CP620_presentation2.ipynb` | Notebooks 04, 05 and 06 combined |

Notebook 04 must be run before 05 and 06, because it writes the hyperparameters they read.

To run a notebook from the command line instead:

```bash
jupyter nbconvert --to notebook --execute --inplace notebooks/04_mnn_presentation.ipynb
```

### 5.2 The follow-up experiments (Week 10: why is the lead small?)

Each script is independent and writes JSON into `results/`.

```bash
python experiments/exp1_3_depth_size_significance.py   # depth, learning curve, significance
python experiments/exp4_synthetic.py                   # SMOTE augmentation to 70,000
python experiments/exp5_depth_on_synth.py              # does more data unlock depth?
python experiments/exp6_lr_check.py                    # is the logistic baseline converged?
python experiments/exp7_fulldata.py                    # all 253,680 real rows
python experiments/make_figures.py                     # rebuild all figures from the JSON
```

Approximate runtimes on a laptop: 6, 5, 7, 2 and 4 minutes respectively.

The longer scripts accept an argument so they can be run a piece at a time:

```bash
python experiments/exp5_depth_on_synth.py 3    # only the three-hidden-layer arm
python experiments/exp4_synthetic.py 2         # only the third arm
```

### 5.3 Verifying backpropagation

Both networks check their own gradients against central finite differences:

```bash
python src/neural_net.py     # the one-hidden-layer network from Week 7
python src/deep_net.py       # the general network, checked at 0, 1 and 2 hidden layers
```

Expected output: every check passes, with maximum relative errors on the order of
1e-7 or smaller.

---

## 6. Project structure

```
CP620-DataMining-Project/
├── CP620_Final_Report.pdf       the final report
├── README.md                    this file
├── requirements.txt             dependencies (minimum versions)
├── requirements-lock.txt        pinned versions, for exact reproduction
├── preprocess.py                regenerates the two working samples from the raw file
├── datasets/                    all data, plus DATASETS.md
├── src/
│   ├── data_loader.py           loads the samples
│   ├── feature_groups.py        the five feature groups
│   ├── naive_bayes.py           Naive Bayes, from scratch
│   ├── decision_tree.py         decision tree, from scratch
│   ├── neural_net.py            one-hidden-layer network, from scratch
│   ├── analysis.py              shared, classifier-agnostic evaluation harness
│   ├── deep_net.py              network with any number of hidden layers
│   ├── synth_data.py            SMOTE for mixed data, plus a bootstrap control
│   └── common.py                shared setup for the follow-up experiments
├── notebooks/                   the Week 3-9 analysis, with outputs saved
├── experiments/                 the Week 10 follow-up scripts
└── results/                     all JSON results and figures
```

`src/analysis.py` is the reason the comparison is fair: it only ever calls `fit`,
`predict`, `predict_proba` and `classes_`, so all three classifiers run identical
evaluation code with no per-model branches.

---

## 7. Reproducing the report

Every number in the report comes from a file in `results/`.

| Report section | Source |
|---|---|
| Tables 2–3 (three-way comparison) | `results/week7_mnn_results.json` |
| Tables 4–5 (feature analyses) | `results/week9_feature_importance.json` |
| Table 6 (imbalanced regime) | `results/week9_ranking_imbalance.json` |
| Tables 7–8 (logistic baseline, depth) | `results/exp6_lr_check.json`, `exp1_depth.json` |
| Tables 9–10 (learning curves) | `results/exp2_learning_curve.json`, `exp7_fulldata.json` |
| Tables 11–13 (synthetic data) | `results/exp4_synthetic.json`, `exp5_depth_on_synth.json` |
| Table 14 (significance) | `results/exp3_significance.json` and `results/exp6_lr_check.json` |
| Figures 1–4 | `results/*.png` |

The results are already saved, so the report can be checked without re-running anything.
Re-running the neural network experiments may shift the third decimal place, because the
network starts from random weights. This does not change any conclusion.

---

## 8. Main findings

1. The neural network scores highest: F1 0.786 and AUC 0.847, against 0.747 / 0.805 for the
   decision tree and 0.732 / 0.819 for Naive Bayes.
2. Backpropagation was verified before any experiment, at a maximum relative error of
   1.72e-07.
3. Depth does not help. Zero to three hidden layers changes F1 by less than 0.005.
4. Sample size does not help. Using all 253,680 real rows moves AUC by 0.001.
5. Synthetic augmentation to 70,000 rows makes the network worse, and the damage scales
   with model capacity: +0.006 at 22 parameters, −0.051 at 1377.
6. A logistic regression with 22 parameters matches the 369-parameter network. Under a
   corrected paired test the F1 difference is not detectable.

The observed plateau near an AUC of 0.85 appears to come mainly from the information in the
21 self-reported survey features, rather than from model capacity or sample size.

---

## 9. Note on the target variable

The label is **self-reported history**: whether the respondent reports having been told by a
health professional that they had coronary heart disease or a myocardial infarction. It is
not a prospective outcome and not a clinical diagnosis. Any screening use would require
prospective clinical validation.
