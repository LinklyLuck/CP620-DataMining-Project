# Datasets

Seven files. Three are the original project datasets, two are real samples used in the
Week 10 follow-up experiments, and two are **synthetic** and must be handled carefully.

Every file has an `is_synthetic` column except the three originals, which are entirely real.

---

## Real data

| File | Rows | Positive rate | What it is |
|---|---|---|---|
| `brfss_raw.csv` | 253,680 | 9.4% | The full cleaned BRFSS 2015 survey. Everything else is drawn from this. |
| `heart_disease_balanced.csv` | 10,000 | 50% | The project's primary balanced sample (Weeks 3–9). |
| `heart_disease_clean.csv` | 15,000 | 9.4% | The imbalanced sample, used for the Precision-Recall study. |
| `real_balanced_10000.csv` | 10,000 | 50% | Balanced sample redrawn by `common.build_balanced(n_per_class=5000, seed=42)`. Used as the base for the Week 10 experiments. |
| `real_balanced_47786.csv` | 47,786 | 50% | **The largest balanced sample the data allows.** It uses all 23,893 positive cases in BRFSS. Used for the learning curve. |

Note that `real_balanced_10000.csv` and `heart_disease_balanced.csv` are both 10,000-row
balanced samples, but they are drawn by different code paths, so they are not identical
row for row. The Week 10 experiments use the first one; Weeks 3–9 use the second.

### The balanced and imbalanced samples overlap

`heart_disease_balanced.csv` and `heart_disease_clean.csv` are **not disjoint**. Both are
drawn from the same source pools with the same seed, and neither excludes the other, so the
smaller draw of each class sits entirely inside the larger one:

| | Overlap |
|---|---|
| Positives | 1,413 — every positive in the imbalanced sample |
| Negatives | 5,000 — every negative in the balanced sample |
| **Total source rows** | **6,413** |

Running `python preprocess.py` regenerates both files and prints this overlap.

This does not create train/test leakage: the two samples are used in separate experiments,
each with its own internal cross-validation, so no row is ever in the training fold and the
test fold of the same fit. It does mean the two experiments are not independent samples, so
the imbalanced results are not an external validation of the balanced results.

---

## Synthetic data

**These two files contain rows that are not real people.** They were generated for one
experiment: testing whether synthetic augmentation raises performance. The answer was no.

| File | Rows | Real rows | Synthetic rows | Method |
|---|---|---|---|---|
| `SYNTHETIC_smote_70000.csv` | 70,000 | 10,000 | 60,000 | SMOTE for mixed data |
| `SYNTHETIC_bootstrap_70000.csv` | 70,000 | 10,000 | 60,000 | Resampling with replacement (control) |

In both files the first 10,000 rows are real and carry `is_synthetic = 0`. The remaining
60,000 carry `is_synthetic = 1`.

### The one rule that matters

**Never build the train/test split after augmenting.**

Synthetic rows are interpolated from real rows, so a split made after augmenting puts a row
and its interpolations on opposite sides. This was measured: augmenting first and splitting
after gives test folds that are roughly 86% synthetic and 14% original, and the neural
network reads F1 = 0.8048 on them against F1 = 0.7565 when scored on real held-out rows.
That inflation of 0.048 is larger than the entire gap between the neural network and the
decision tree that the project set out to study.

To use these files correctly, filter first:

Split the **real** data into train and test first, then augment **only the training part**.
Do not build the split after augmenting: the real rows in these files were used to generate
the synthetic ones, so a split made afterwards puts related rows on both sides.

```python
for tr, te in StratifiedKFold(5, shuffle=True, random_state=42).split(X, y):
    X_tr, y_tr = smote_nc(X.iloc[tr], y.iloc[tr], 70000, seed=42)   # augment TRAIN only
    model.fit(X_tr, y_tr)
    score(model, X.iloc[te], y.iloc[te])                            # test stays REAL
```

### How the synthetic rows were made

Plain SMOTE interpolates between neighbours, which would produce values such as
`HighBP = 0.43`. That is not a person. Only 3 of the 21 features are continuous, so the
generator handles the three column types separately:

- **Continuous** (`BMI`, `MentHlth`, `PhysHlth`) — interpolated between a row and one of
  its 5 nearest neighbours of the same class, then rounded.
- **Ordinal** (`Diabetes`, `GenHlth`, `Age`, `Education`, `Income`) — interpolated, then
  snapped to the nearest legal level.
- **Binary** (the other 13) — inherited from one of the two parent rows, never averaged.

Neighbours are found on standardised columns so that `BMI` does not dominate the distance.
Class balance is preserved. The code is `src/synth_data.py`.

### Validation of the generated rows

- All 18 binary and ordinal features stayed **100% within their legal domains**.
- All 3 continuous features stayed within the observed real range.
- Largest absolute standardised mean difference across all 21 features: **0.043**
  (every feature below the conventional 0.1 threshold).
- Largest binary frequency shift: **0.013**.
- Interpolation shrinks the spread slightly. For example the standard deviation of `BMI`
  falls from 6.68 to 5.88. This is a known property of SMOTE, and it is part of why the
  more flexible models were harmed by it.

### Important: these files do not reproduce the experiment numbers

In the experiments, synthetic rows were regenerated **inside each cross-validation fold**,
from that fold's training portion only, with seed `42 + fold_index`. That is what keeps the
test folds clean. These two files are a single standalone generation from the full
10,000-row sample, provided so the data can be inspected.

To reproduce the reported results, run the code rather than using these files:

```bash
python experiments/exp4_synthetic.py
```

---

## What the synthetic experiment found

| Training data | Decision Tree | Logistic regression | Neural network |
|---|---|---|---|
| Real only, 8,000 | 0.7493 | 0.7611 | **0.7739** |
| SMOTE to 70,000 | 0.7505 | 0.7672 | 0.7565 |
| Bootstrap to 70,000 (control) | 0.7410 | 0.7604 | 0.7495 |

F1 measured on real held-out rows. Synthetic augmentation did not help. The neural network
fell steadily as synthetic rows were added, and the damage scaled with model capacity:
+0.006 for the 22-parameter linear model, −0.017 at 369 parameters, −0.025 at 497, and
−0.051 at 1377.

The bootstrap control adds no information at all, only copies. SMOTE beating it (0.7565
against 0.7495) shows interpolation contributes something, but not enough to beat simply
using the real data.

---

## Source and licence

All real data derives from the Heart Disease Health Indicators Dataset, released on Kaggle
by Alex Teboul from cleaned CDC BRFSS 2015 data.

- Cleaned release: https://www.kaggle.com/datasets/alexteboul/heart-disease-health-indicators-dataset
- Original survey: https://www.cdc.gov/brfss/annual_data/annual_2015.html
- Licence on Kaggle: CC0 Public Domain

The target is a **self-reported history**: whether the respondent reports having been told
by a health professional that they had coronary heart disease or a myocardial infarction.
It is not a prospective outcome and not a clinical diagnosis.
