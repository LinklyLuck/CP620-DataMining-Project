"""Experiment 7: the learning curve on the FULL real dataset.

The balanced curve had to stop at 47,786 rows, because that already used every one
of the 23,893 positive cases in BRFSS. Going further with real data means keeping
the natural 9.4% imbalance, which unlocks all 253,680 rows -- 5.3x more rows and
about 10x more negatives.

AUC is the headline metric because it does not depend on the class balance, so these
numbers compare directly with the balanced experiments. Average precision is reported
alongside it, since that is the right companion metric under imbalance.

Run:  python experiments/exp7_fulldata.py                    (both models, replaces the json)
      python experiments/exp7_fulldata.py "MNN (1 hidden)"   (one model, appends)
"""

import sys, time
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import load_full, net, HP, save_rows, RESULTS

from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, average_precision_score

SIZES = [20000, 50000, 100000, 180000, 253680]


def make(name):
    """sklearn LR is used here because it converges; the nets share one trainer."""
    if name == 'LR (sklearn)':
        return make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
    if name == 'MNN (1 hidden)':
        return net((HP['hidden_units'],))
    if name == 'Deep (2 hidden)':
        return net((16, 8))
    raise ValueError(name)


def run_sizes(X, y, model_name, sizes, folds_n=3, seed=42):
    """Nested real subsets so the curve is comparable across sizes."""
    rows = []
    for n in sizes:
        Xs, ys = X.iloc[:n], y.iloc[:n]
        aucs, aps = [], []
        t0 = time.time()
        for tr, te in StratifiedKFold(folds_n, shuffle=True, random_state=seed).split(Xs, ys):
            m = make(model_name)
            m.fit(Xs.iloc[tr], ys.iloc[tr])
            p = m.predict_proba(Xs.iloc[te])[:, 1]
            aucs.append(roc_auc_score(ys.iloc[te], p))
            aps.append(average_precision_score(ys.iloc[te], p))
        aucs, aps = np.array(aucs), np.array(aps)
        rows.append({'model': model_name, 'n': int(n), 'pos_rate': float(ys.mean()),
                     'auc': aucs.mean(), 'auc_std': aucs.std(),
                     'ap': aps.mean(), 'ap_std': aps.std()})
        print(f"  {model_name:16s} n={n:>7,}  AUC={aucs.mean():.4f}+-{aucs.std():.4f}  "
              f"AP={aps.mean():.4f}  ({time.time()-t0:.0f}s)")
    return rows


if __name__ == '__main__':
    print("=" * 78)
    print("EXPERIMENT 7 - LEARNING CURVE ON ALL 253,680 REAL ROWS")
    print("=" * 78)
    X, y = load_full()
    print(f"full survey: {len(X):,} rows, {int(y.sum()):,} positives ({y.mean():.1%})")
    if len(sys.argv) > 1:
        # single model: append, so models can be run one at a time
        save_rows(run_sizes(X, y, sys.argv[1], SIZES), 'exp7_fulldata.json', append=True)
    else:
        # full run: collect both models first, then write once
        all_rows = []
        for mname in ['LR (sklearn)', 'MNN (1 hidden)']:
            all_rows.extend(run_sizes(X, y, mname, SIZES))
        save_rows(all_rows, 'exp7_fulldata.json')
    print(f"\nSaved to {RESULTS}")
