"""Experiments 1-3: is the MNN's small lead about depth, data size, or noise?

  1. DEPTH      -- 0 / 1 / 2 / 3 hidden layers on the same folds
  2. DATA SIZE  -- learning curve on real balanced data, up to ~47,786 rows
  3. IS IT REAL -- 5x5 repeated CV, then paired t-test and Wilcoxon

Run:  python experiments/exp1_3_depth_size_significance.py
      python experiments/exp1_3_depth_size_significance.py 1     (just experiment 1)
"""

import sys, time
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import (build_balanced, make_factories, save_rows, save_obj, RESULTS,
                    corrected_paired_test)

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, roc_auc_score
from scipy import stats

USE_ALL = ['NB', 'DT', 'LR (0 hidden)', 'MNN (1 hidden)',
           'Deep (2 hidden)', 'Deep (3 hidden)']
USE_CURVE = ['NB', 'DT', 'LR (0 hidden)', 'MNN (1 hidden)', 'Deep (2 hidden)']


def cv_scores(X, y, factory, folds):
    """One model over the given folds; returns per-fold F1 and AUC."""
    f1s, aucs = [], []
    for tr, te in folds:
        m = factory()
        m.fit(X.iloc[tr], y.iloc[tr])
        f1s.append(f1_score(y.iloc[te], m.predict(X.iloc[te])))
        aucs.append(roc_auc_score(y.iloc[te], m.predict_proba(X.iloc[te])[:, 1]))
    return np.array(f1s), np.array(aucs)


def experiment_depth(X, y, seed=42):
    """Depth is the only variable: same folds, same trainer, same data."""
    print("=" * 74)
    print(f"EXPERIMENT 1 - DEPTH   ({len(X):,} real balanced rows, 5-fold CV)")
    print("=" * 74)
    folds = list(StratifiedKFold(5, shuffle=True, random_state=seed).split(X, y))
    facs = make_factories()
    rows = []
    for name in USE_ALL:
        t0 = time.time()
        f1s, aucs = cv_scores(X, y, facs[name], folds)
        n_par = facs[name]().n_params(X.shape[1]) if 'hidden' in name else None
        rows.append({'model': name, 'f1_mean': f1s.mean(), 'f1_std': f1s.std(),
                     'auc_mean': aucs.mean(), 'auc_std': aucs.std(),
                     'n_params': n_par, 'f1_folds': f1s.tolist()})
        p = f"{n_par:>5d}" if n_par else "    -"
        print(f"  {name:18s} F1={f1s.mean():.4f}+-{f1s.std():.4f}  "
              f"AUC={aucs.mean():.4f}+-{aucs.std():.4f}  params={p}  ({time.time()-t0:.0f}s)")
    return rows


def experiment_learning_curve(seed=42):
    """Nested real subsets. The top size uses every positive case in BRFSS."""
    print("\n" + "=" * 74)
    print("EXPERIMENT 2 - DATA SIZE   (real data only, nothing simulated)")
    print("=" * 74)
    X_full, y_full = build_balanced(seed=seed)          # every positive available
    n_max = len(y_full)
    sizes = [4000, 8000, 16000, 28000, n_max]
    print(f"  largest balanced sample possible: {n_max:,} rows "
          f"({int(y_full.sum()):,} positives = all of them)")
    facs = make_factories()
    out = {name: [] for name in USE_CURVE}
    for n in sizes:
        Xs, ys = X_full.iloc[:n], y_full.iloc[:n]
        folds = list(StratifiedKFold(5, shuffle=True, random_state=seed).split(Xs, ys))
        line = f"  n={n:>6,}: "
        for name in USE_CURVE:
            f1s, aucs = cv_scores(Xs, ys, facs[name], folds)
            out[name].append({'n': int(n), 'f1': f1s.mean(), 'f1_std': f1s.std(),
                              'auc': aucs.mean(), 'auc_std': aucs.std()})
            line += f"{name.split()[0]}={f1s.mean():.3f} "
        print(line)
    return {'sizes': sizes, 'n_max': int(n_max), 'curve': out}


def experiment_significance(X, y, repeats=5, seed=42):
    """Repeated CV so the gaps can be tested instead of eyeballed."""
    print("\n" + "=" * 74)
    print(f"EXPERIMENT 3 - IS IT REAL   ({repeats}x5-fold repeated CV + paired tests)")
    print("=" * 74)
    facs = make_factories()
    scores = {n: {'f1': [], 'auc': []} for n in USE_CURVE}
    for r in range(repeats):
        folds = list(StratifiedKFold(5, shuffle=True, random_state=seed + r).split(X, y))
        for name in USE_CURVE:
            f1s, aucs = cv_scores(X, y, facs[name], folds)
            scores[name]['f1'].extend(f1s.tolist())
            scores[name]['auc'].extend(aucs.tolist())
        print(f"  repeat {r+1}/{repeats} done")

    print(f"\n  {'model':18s}{'F1':>19s}{'AUC':>19s}")
    for name in USE_CURVE:
        f = np.array(scores[name]['f1']); a = np.array(scores[name]['auc'])
        print(f"  {name:18s}{f.mean():>12.4f}+-{f.std():.4f}{a.mean():>12.4f}+-{a.std():.4f}")

    # test/train ratio of the outer 5-fold split, needed by the correction
    n_test = len(X) // 5
    n_train = len(X) - n_test

    base = 'MNN (1 hidden)'
    tests = []
    print(f"\n  Paired against {base}   (corrected resampled t-test, Nadeau-Bengio)")
    print(f"  {'vs':18s}{'dF1':>9s}{'uncorr p':>11s}{'corrected p':>13s}{'Wilcoxon':>11s}  reading")
    for name in USE_CURVE:
        if name == base:
            continue
        a = np.array(scores[base]['f1']); b = np.array(scores[name]['f1'])
        d, p_un, p_corr = corrected_paired_test(a, b, n_test, n_train)
        try:
            _, p_w = stats.wilcoxon(a, b)
        except ValueError:
            p_w = float('nan')
        reading = ('difference detected' if p_corr < .05 else 'no difference detected')
        tests.append({'vs': name, 'mean_diff_f1': d,
                      't_p_uncorrected': p_un, 't_p_corrected': p_corr,
                      'wilcoxon_p': float(p_w), 'reading': reading})
        print(f"  {name:18s}{d:>+9.4f}{p_un:>11.3f}{p_corr:>13.3f}{p_w:>11.3f}  {reading}")
    print("\n  The corrected test is the primary result. Folds share training data, so the")
    print("  uncorrected t-test and Wilcoxon both assume an independence that does not hold.")
    return {'scores': scores, 'paired_tests': tests, 'repeats': repeats,
            'correction': {'n_test': n_test, 'n_train': n_train,
                           'variance_term': 1/len(scores[base]['f1']) + n_test/n_train}}


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    t0 = time.time()
    X, y = build_balanced(n_per_class=5000, seed=42)     # same size as Week 7

    if which in ('all', '1'):
        save_rows(experiment_depth(X, y), 'exp1_depth.json')
    if which in ('all', '2'):
        # written as a single object, matching the file shipped with the project
        save_obj(experiment_learning_curve(), 'exp2_learning_curve.json')
    if which in ('all', '3'):
        save_obj(experiment_significance(X, y), 'exp3_significance.json')

    print(f"\nSaved to {RESULTS}   total {time.time()-t0:.0f}s")
