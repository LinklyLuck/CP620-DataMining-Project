"""Experiment 5: does more data unlock depth?

Experiment 1 found that extra hidden layers do not help on 8,000 real rows. A common
argument is that deeper networks only pay off once there is more data, so the same
depth ladder is run again on training folds grown to 70,000 rows with SMOTE.

Test folds stay REAL, so the two ladders can be compared directly. The gap between
them also shows how much each model size is damaged by synthetic data.

Run:  python experiments/exp5_depth_on_synth.py         (all depths, replaces the json)
      python experiments/exp5_depth_on_synth.py 3       (one depth, appends to the json)
"""

import sys, time
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import build_balanced, net, save_rows, DEPTH_LADDER, RESULTS
from synth_data import smote_nc

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, roc_auc_score


def run_depth(X, y, di, target=70000, seed=42, augment=True):
    """One depth: grow each training fold, score on the real test fold."""
    label, hidden = DEPTH_LADDER[di]
    folds = list(StratifiedKFold(5, shuffle=True, random_state=seed).split(X, y))
    f1s, aucs = [], []
    t0 = time.time()
    for fi, (tr, te) in enumerate(folds):
        X_tr, y_tr = X.iloc[tr], y.iloc[tr]
        if augment:
            X_tr, y_tr = smote_nc(X_tr, y_tr, target, seed=seed + fi)   # TRAIN only
        m = net(hidden)
        m.fit(X_tr, y_tr)
        X_te, y_te = X.iloc[te], y.iloc[te]                             # REAL test
        f1s.append(f1_score(y_te, m.predict(X_te)))
        aucs.append(roc_auc_score(y_te, m.predict_proba(X_te)[:, 1]))
    f1s, aucs = np.array(f1s), np.array(aucs)
    n_par = net(hidden).n_params(X.shape[1])
    tag = f'SMOTE {target:,}' if augment else 'real only'
    print(f"  {label:18s} [{tag:14s}] F1={f1s.mean():.4f}+-{f1s.std():.4f}  "
          f"AUC={aucs.mean():.4f}+-{aucs.std():.4f}  params={n_par:>5d}  ({time.time()-t0:.0f}s)")
    return [{'model': label, 'hidden_layers': list(hidden),
             'train_size': int(target if augment else len(folds[0][0])),
             'augmented': bool(augment), 'f1': f1s.mean(), 'f1_std': f1s.std(),
             'auc': aucs.mean(), 'auc_std': aucs.std(), 'n_params': n_par,
             'f1_folds': f1s.tolist()}]


if __name__ == '__main__':
    print("=" * 78)
    print("EXPERIMENT 5 - DEPTH LADDER ON SMOTE-AUGMENTED DATA")
    print("=" * 78)
    X, y = build_balanced(n_per_class=5000, seed=42)
    print("per fold: real 8,000 -> SMOTE 70,000 for training; testing on real 2,000")
    if len(sys.argv) > 1:
        # single depth: append, so depths can be run one at a time
        save_rows(run_depth(X, y, int(sys.argv[1])), 'exp5_depth_on_synth.json', append=True)
    else:
        # full run: collect all depths first, then write once
        all_rows = []
        for di in range(len(DEPTH_LADDER)):
            all_rows.extend(run_depth(X, y, di))
        save_rows(all_rows, 'exp5_depth_on_synth.json')
    print(f"\nSaved to {RESULTS}")
