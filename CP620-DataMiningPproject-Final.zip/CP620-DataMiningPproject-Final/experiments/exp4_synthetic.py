"""Experiment 4: does SMOTE augmentation to 70,000 rows help?

Design, and why it matters:
  Each fold grows only its REAL TRAINING part with synthetic rows. Every score is
  taken on real, held-out rows. Testing on synthetic rows would inflate the result,
  because those rows are interpolated from the training data -- the last arm does
  exactly that on purpose, to show how large the inflation is.

  A bootstrap arm is the control: it grows the data by plain copying and therefore
  adds no information. Whatever SMOTE gains above bootstrap came from interpolation.

Run:  python experiments/exp4_synthetic.py          (all arms, replaces the json)
      python experiments/exp4_synthetic.py 3        (just arm 3, appends to the json)
"""

import sys, time
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import build_balanced, make_factories, save_rows, RESULTS
from synth_data import smote_nc, bootstrap

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, roc_auc_score

USE = ['DT', 'LR (0 hidden)', 'MNN (1 hidden)']
FACS = make_factories()

ARMS = [
    ('real only',                     None,       None),
    ('SMOTE -> 20,000',               smote_nc,   20000),
    ('SMOTE -> 40,000',               smote_nc,   40000),
    ('SMOTE -> 70,000',               smote_nc,   70000),
    ('bootstrap -> 70,000 (control)', bootstrap,  70000),
]


def run_arm(X, y, i, seed=42):
    """One arm: grow the training folds, score on the real test folds."""
    label, gen, target = ARMS[i]
    folds = list(StratifiedKFold(5, shuffle=True, random_state=seed).split(X, y))
    if target is None:
        target = len(folds[0][0])
    per = {m: {'f1': [], 'auc': []} for m in USE}
    t0 = time.time()
    for fi, (tr, te) in enumerate(folds):
        X_tr, y_tr = X.iloc[tr], y.iloc[tr]
        if gen is not None:
            X_tr, y_tr = gen(X_tr, y_tr, target, seed=seed + fi)   # TRAIN only
        X_te, y_te = X.iloc[te], y.iloc[te]                        # test stays REAL
        for m in USE:
            mod = FACS[m]()
            mod.fit(X_tr, y_tr)
            per[m]['f1'].append(f1_score(y_te, mod.predict(X_te)))
            per[m]['auc'].append(roc_auc_score(y_te, mod.predict_proba(X_te)[:, 1]))
    rows, line = [], f"  {label:32s}"
    for m in USE:
        f = np.array(per[m]['f1']); a = np.array(per[m]['auc'])
        rows.append({'arm': label, 'train_size': int(target), 'model': m,
                     'f1': f.mean(), 'f1_std': f.std(), 'auc': a.mean(),
                     'auc_std': a.std(), 'tested_on': 'real'})
        line += f"{m.split()[0]}: F1={f.mean():.4f} "
    print(line + f" ({time.time()-t0:.0f}s)")
    return rows


def run_wrong_way(X, y, seed=42):
    """The mistake to avoid: augment first, split afterwards, and watch F1 inflate.

    Note the test folds here are not purely synthetic. Cross-validation is applied to the
    whole augmented set, so each fold holds about 86% synthetic rows and 14% original ones.
    The inflation comes from splitting after augmentation, which puts rows and the rows
    interpolated from them on opposite sides of the split.
    """
    print("\n  --- the wrong way: augment first, then split (test folds ~86% synthetic) ---")
    Xa, ya = smote_nc(X, y, 70000, seed=seed)
    folds = list(StratifiedKFold(5, shuffle=True, random_state=seed).split(Xa, ya))
    rows, line = [], "  augmented test folds (INVALID)  "
    for m in USE:
        f1s, aus = [], []
        for tr, te in folds:
            mod = FACS[m]()
            mod.fit(Xa.iloc[tr], ya.iloc[tr])
            f1s.append(f1_score(ya.iloc[te], mod.predict(Xa.iloc[te])))
            aus.append(roc_auc_score(ya.iloc[te], mod.predict_proba(Xa.iloc[te])[:, 1]))
        rows.append({'arm': 'augmented test folds (INVALID)', 'train_size': 70000, 'model': m,
                     'f1': float(np.mean(f1s)), 'f1_std': float(np.std(f1s)),
                     'auc': float(np.mean(aus)), 'auc_std': float(np.std(aus)),
                     'tested_on': 'augmented mix (~86% synthetic)'})
        line += f"{m.split()[0]}: F1={np.mean(f1s):.4f} "
    print(line)
    return rows


if __name__ == '__main__':
    print("=" * 78)
    print("EXPERIMENT 4 - SYNTHETIC AUGMENTATION TO 70,000 ROWS")
    print("=" * 78)
    X, y = build_balanced(n_per_class=5000, seed=42)
    print(f"real data {len(X):,} rows -> per fold: train 8,000 / test 2,000 (test is REAL)")
    if len(sys.argv) > 1:
        # single arm: append, so running arms one at a time builds the file up
        save_rows(run_arm(X, y, int(sys.argv[1])), 'exp4_synthetic.json', append=True)
    else:
        # full run: collect everything first, then write once, replacing any old file
        all_rows = []
        for i in range(len(ARMS)):
            all_rows.extend(run_arm(X, y, i))
        all_rows.extend(run_wrong_way(X, y))
        save_rows(all_rows, 'exp4_synthetic.json')
    print(f"\nSaved to {RESULTS}")
