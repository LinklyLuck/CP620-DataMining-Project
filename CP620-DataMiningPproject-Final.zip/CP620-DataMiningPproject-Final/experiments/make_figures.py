"""Rebuild every figure from the saved result files.

Run this after the experiments, or any time the json files change:
    python experiments/make_figures.py
"""

import sys, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')                       # no display needed, write straight to file
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import RESULTS

NAVY, TERRA, GREEN, MUTED, BLUE = '#21295C', '#B85042', '#065F46', '#64748B', '#065A82'


def load(name):
    p = RESULTS / name
    return json.load(open(p)) if p.exists() else None


def fig_depth():
    """Experiment 1: performance against depth on real data."""
    d = load('exp1_depth.json')
    if not d:
        return
    nets = [r for r in d if r.get('n_params')]
    labels = ['0\n(logistic)', '1\n(16)', '2\n(16,8)', '3\n(32,16,8)']
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.6))
    for ax, key, ekey, title, c in [(axes[0], 'f1_mean', 'f1_std', 'F1', BLUE),
                                    (axes[1], 'auc_mean', 'auc_std', 'AUC', TERRA)]:
        v = [r[key] for r in nets]; e = [r[ekey] for r in nets]
        ax.errorbar(range(len(v)), v, yerr=e, marker='o', ms=8, lw=2, capsize=5, color=c)
        ax.set_xticks(range(len(v))); ax.set_xticklabels(labels[:len(v)])
        ax.set_xlabel('hidden layers'); ax.set_ylabel(title)
        ax.set_title(f'{title} vs depth — 10,000 real rows'); ax.grid(alpha=.3)
        for i, y in enumerate(v):
            ax.annotate(f"{y:.4f}\n{nets[i]['n_params']}p", (i, y), fontsize=8,
                        textcoords='offset points', xytext=(0, 12), ha='center')
    plt.tight_layout(); plt.savefig(RESULTS / 'depth_effect.png', dpi=120, bbox_inches='tight')
    plt.close(); print('  depth_effect.png')


def fig_learning_curve():
    """Experiment 2: real-data learning curve on the balanced sample."""
    raw = load('exp2_learning_curve.json')
    if not raw:
        return
    curve = (raw[0] if isinstance(raw, list) else raw)['curve']
    colors = {'NB': BLUE, 'DT': TERRA, 'LR (0 hidden)': MUTED,
              'MNN (1 hidden)': GREEN, 'Deep (2 hidden)': '#1C7293'}
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.6))
    for key, ax, title in [('f1', axes[0], 'F1'), ('auc', axes[1], 'AUC')]:
        for name, rows in curve.items():
            ax.plot([r['n'] for r in rows], [r[key] for r in rows],
                    marker='o', lw=2, label=name, color=colors.get(name))
        ax.set_xlabel('training rows (real)'); ax.set_ylabel(title)
        ax.set_title(f'{title} vs data size — curves are flat')
        ax.grid(alpha=.3); ax.legend(fontsize=8)
    plt.tight_layout(); plt.savefig(RESULTS / 'learning_curve.png', dpi=120, bbox_inches='tight')
    plt.close(); print('  learning_curve.png')


def fig_synthetic():
    """Experiment 4: augmentation arms, plus the inflation from a synthetic test set."""
    rows = load('exp4_synthetic.json')
    if not rows:
        return
    df = {}
    for r in rows:
        df.setdefault(r['model'], {})[r['arm']] = r
    arms = ['real only', 'SMOTE -> 20,000', 'SMOTE -> 40,000',
            'SMOTE -> 70,000', 'bootstrap -> 70,000 (control)']
    short = ['real\n8,000', 'SMOTE\n20,000', 'SMOTE\n40,000', 'SMOTE\n70,000',
             'bootstrap\n70,000\n(control)']
    colors = {'DT': TERRA, 'LR (0 hidden)': MUTED, 'MNN (1 hidden)': GREEN}
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.8))
    ax = axes[0]
    for m, c in colors.items():
        if m not in df:
            continue
        v = [df[m][a]['f1'] for a in arms if a in df[m]]
        e = [df[m][a]['f1_std'] for a in arms if a in df[m]]
        ax.errorbar(range(len(v)), v, yerr=e, marker='o', ms=7, lw=2,
                    capsize=4, label=m, color=c)
    ax.set_xticks(range(len(arms))); ax.set_xticklabels(short, fontsize=8)
    ax.set_ylabel('F1 (measured on REAL held-out rows)')
    ax.set_title('Synthetic augmentation does not help', fontsize=10)
    ax.grid(alpha=.3); ax.legend(fontsize=8)

    ax = axes[1]
    x = np.arange(2); w = 0.25
    for i, (m, c) in enumerate(colors.items()):
        if m not in df or 'augmented test folds (INVALID)' not in df[m]:
            continue
        vals = [df[m]['SMOTE -> 70,000']['f1'], df[m]['augmented test folds (INVALID)']['f1']]
        ax.bar(x + (i - 1) * w, vals, w, label=m, color=c)
        for xx, yy in zip(x + (i - 1) * w, vals):
            ax.annotate(f'{yy:.3f}', (xx, yy), fontsize=7.5, ha='center',
                        textcoords='offset points', xytext=(0, 3))
    ax.set_xticks(x)
    ax.set_xticklabels(['tested on\nREAL held-out\nrows (valid)', 'augmented folds\n~86% synthetic\n(INVALID)'],
                       fontsize=9)
    ax.set_ylabel('F1'); ax.set_ylim(0.70, 0.83)
    ax.set_title('Why the split must come before augmentation', fontsize=10)
    ax.grid(alpha=.3, axis='y'); ax.legend(fontsize=8)
    plt.tight_layout(); plt.savefig(RESULTS / 'synthetic_augmentation.png', dpi=120,
                                    bbox_inches='tight')
    plt.close(); print('  synthetic_augmentation.png')


def fig_depth_on_synth():
    """Experiment 5: the two depth ladders, and the dose-response curve."""
    real, syn = load('exp1_depth.json'), load('exp5_depth_on_synth.json')
    if not real or not syn:
        return
    order = ['LR (0 hidden)', 'MNN (1 hidden)', 'Deep (2 hidden)', 'Deep (3 hidden)']
    rd = {r['model']: r for r in real}; sd = {r['model']: r for r in syn}
    order = [m for m in order if m in rd and m in sd]
    labels = ['0\n22p', '1\n369p', '2\n497p', '3\n1377p'][:len(order)]
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.7))
    for ax, rk, sk, title in [(axes[0], 'f1_mean', 'f1', 'F1'),
                              (axes[1], 'auc_mean', 'auc', 'AUC')]:
        ax.errorbar(range(len(order)), [rd[m][rk] for m in order],
                    marker='o', ms=8, lw=2.5, label='real 8,000', color=GREEN)
        ax.errorbar(range(len(order)), [sd[m][sk] for m in order],
                    marker='s', ms=8, lw=2.5, label='SMOTE 70,000', color=TERRA)
        ax.set_xticks(range(len(order))); ax.set_xticklabels(labels, fontsize=8)
        ax.set_xlabel('hidden layers'); ax.set_ylabel(f'{title} (on REAL rows)')
        ax.set_title(f'{title}: more data did NOT unlock depth', fontsize=10)
        ax.grid(alpha=.3); ax.legend(fontsize=9)
    ax = axes[2]
    pars = [rd[m]['n_params'] for m in order]
    delta = [sd[m]['f1'] - rd[m]['f1_mean'] for m in order]
    ax.axhline(0, color=MUTED, lw=1, ls='--')
    ax.plot(pars, delta, marker='o', ms=9, lw=2.5, color=NAVY)
    for p, d, m in zip(pars, delta, order):
        ax.annotate(f"{m.split()[0]}\n{d:+.3f}", (p, d), fontsize=8,
                    textcoords='offset points', xytext=(8, -4))
    ax.set_xscale('log'); ax.set_xlabel('parameters (log scale)')
    ax.set_ylabel('F1 change from synthetic data')
    ax.set_title('Dose-response: more capacity, more damage', fontsize=10)
    ax.grid(alpha=.3)
    plt.tight_layout(); plt.savefig(RESULTS / 'depth_on_synthetic.png', dpi=120,
                                    bbox_inches='tight')
    plt.close(); print('  depth_on_synthetic.png')


def fig_fulldata():
    """Experiment 7: AUC across both data regimes, 4,000 up to 253,680 rows."""
    full, balraw = load('exp7_fulldata.json'), load('exp2_learning_curve.json')
    if not full:
        return
    fd = {}
    for r in full:
        fd.setdefault(r['model'], []).append(r)
    for k in fd:
        fd[k] = sorted(fd[k], key=lambda r: r['n'])
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.8))
    ax = axes[0]
    if balraw:
        bal = (balraw[0] if isinstance(balraw, list) else balraw)['curve']
        for name, c, lbl in [('MNN (1 hidden)', GREEN, 'MNN — balanced real'),
                             ('LR (0 hidden)', MUTED, 'LR — balanced real')]:
            if name in bal:
                ax.plot([r['n'] for r in bal[name]], [r['auc'] for r in bal[name]],
                        marker='o', lw=2, color=c, label=lbl,
                        ls='--' if 'LR' in name else '-')
    for name, c, lbl in [('MNN (1 hidden)', TERRA, 'MNN — full real 9.4%'),
                         ('LR (sklearn)', NAVY, 'LR — full real 9.4%')]:
        if name in fd:
            ax.plot([r['n'] for r in fd[name]], [r['auc'] for r in fd[name]],
                    marker='s', lw=2, color=c, label=lbl, ls='--' if 'LR' in name else '-')
    ax.set_xscale('log'); ax.set_xlabel('training rows (log scale)'); ax.set_ylabel('AUC')
    ax.set_ylim(0.76, 0.87)
    ax.set_title('AUC from 4,000 to 253,680 real rows — flat', fontsize=10)
    ax.grid(alpha=.3); ax.legend(fontsize=7.5, loc='lower right')

    ax = axes[1]
    if 'LR (sklearn)' in fd and 'MNN (1 hidden)' in fd:
        ns = [r['n'] for r in fd['MNN (1 hidden)']]
        x = np.arange(len(ns)); w = 0.35
        ax.bar(x - w/2, [r['auc'] for r in fd['LR (sklearn)']], w,
               label='LR (22 params)', color=NAVY)
        ax.bar(x + w/2, [r['auc'] for r in fd['MNN (1 hidden)']], w,
               label='MNN (369 params)', color=TERRA)
        ax.set_xticks(x); ax.set_xticklabels([f'{n//1000}k' for n in ns], fontsize=9)
        ax.set_ylim(0.80, 0.88); ax.set_xlabel('training rows'); ax.set_ylabel('AUC')
        ax.set_title('22 params ties 369 params at every size', fontsize=10)
        ax.grid(alpha=.3, axis='y'); ax.legend(fontsize=8)
    plt.tight_layout(); plt.savefig(RESULTS / 'fulldata_curve.png', dpi=120, bbox_inches='tight')
    plt.close(); print('  fulldata_curve.png')


if __name__ == '__main__':
    print("Rebuilding figures:")
    for fn in (fig_depth, fig_learning_curve, fig_synthetic, fig_depth_on_synth, fig_fulldata):
        try:
            fn()
        except Exception as e:                       # keep going if one file is missing
            print(f"  skipped {fn.__name__}: {e}")
    print(f"Done -> {RESULTS}")
