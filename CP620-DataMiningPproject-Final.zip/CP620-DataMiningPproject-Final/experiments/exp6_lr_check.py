"""Experiment 6: is the logistic-regression baseline trained properly?

Why this check is needed:
  The 0-hidden-layer network is trained by mini-batch SGD with early stopping, the
  same trainer as the deeper nets. That keeps the depth comparison fair, but it also
  means the linear model may stop before it has fully converged -- which would make
  the neural network look better than it really is.

  So the same comparison is repeated with scikit-learn's LogisticRegression (lbfgs,
  properly converged) as a reference. If the SGD version is under-trained, this will
  show it, and the true size of the neural network's advantage becomes visible.

Run:  python experiments/exp6_lr_check.py
"""

import sys, time, json
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from common import build_balanced, make_factories, RESULTS, corrected_paired_test

from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import f1_score, roc_auc_score
from scipy import stats

NAMES = ['LR (my SGD, 0 hidden)', 'LR (sklearn lbfgs)', 'MNN (1 hidden)']


def build(name, facs):
    """Three models: my SGD linear net, a converged linear model, and the MNN."""
    if name == 'LR (my SGD, 0 hidden)':
        return facs['LR (0 hidden)']()
    if name == 'LR (sklearn lbfgs)':
        # standardise first, otherwise lbfgs converges slowly on raw BMI
        return make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
    return facs['MNN (1 hidden)']()


def main(repeats=5, seed=42):
    print("=" * 74)
    print("EXPERIMENT 6 - LOGISTIC REGRESSION CONVERGENCE CHECK")
    print("=" * 74)
    X, y = build_balanced(n_per_class=5000, seed=seed)
    facs = make_factories()
    f1s = {n: [] for n in NAMES}
    aus = {n: [] for n in NAMES}

    t0 = time.time()
    for rep in range(repeats):                       # 5 repeats x 5 folds = 25 scores
        for tr, te in StratifiedKFold(5, shuffle=True, random_state=seed + rep).split(X, y):
            Xtr, ytr, Xte, yte = X.iloc[tr], y.iloc[tr], X.iloc[te], y.iloc[te]
            for name in NAMES:
                m = build(name, facs)
                m.fit(Xtr, ytr)
                f1s[name].append(f1_score(yte, m.predict(Xte)))
                aus[name].append(roc_auc_score(yte, m.predict_proba(Xte)[:, 1]))
        print(f"  repeat {rep+1}/{repeats} done")

    print(f"\n  {'model':26s}{'F1':>19s}{'AUC':>19s}")
    for n in NAMES:
        f = np.array(f1s[n]); a = np.array(aus[n])
        print(f"  {n:26s}{f.mean():>12.4f}+-{f.std():.4f}{a.mean():>12.4f}+-{a.std():.4f}")

    print()
    n_test = len(X) // 5                             # ratio needed by the correction
    n_train = len(X) - n_test
    mnn_f = np.array(f1s['MNN (1 hidden)'])
    mnn_a = np.array(aus['MNN (1 hidden)'])
    tests = []
    print(f"  {'comparison':34s}{'diff':>9s}{'uncorr p':>11s}{'corrected p':>13s}{'Wilcoxon':>11s}")
    for n in NAMES[:2]:                              # paired tests against the MNN
        d, p_un, p_corr = corrected_paired_test(mnn_f, np.array(f1s[n]), n_test, n_train)
        _, p_w = stats.wilcoxon(mnn_f, np.array(f1s[n]))
        tests.append({'metric': 'f1', 'comparison': f'MNN vs {n}', 'diff': d,
                      't_p_uncorrected': p_un, 't_p_corrected': p_corr,
                      'wilcoxon_p': float(p_w)})
        print(f"  F1  MNN vs {n:23s}{d:>+9.4f}{p_un:>11.3f}{p_corr:>13.3f}{p_w:>11.3f}")
    lr_a = np.array(aus['LR (sklearn lbfgs)'])
    d, p_un, p_corr = corrected_paired_test(mnn_a, lr_a, n_test, n_train)
    _, p_w = stats.wilcoxon(mnn_a, lr_a)
    tests.append({'metric': 'auc', 'comparison': 'MNN vs LR (sklearn lbfgs)', 'diff': d,
                  't_p_uncorrected': p_un, 't_p_corrected': p_corr, 'wilcoxon_p': float(p_w)})
    print(f"  AUC MNN vs LR (sklearn lbfgs)  {d:>+9.4f}{p_un:>11.3f}{p_corr:>13.3f}{p_w:>11.3f}")
    print("\n  The corrected resampled t-test is the primary result; the other two assume")
    print("  independent samples, which cross-validation folds are not.")
    print(f"  ({time.time()-t0:.0f}s)")

    json.dump({'scores': {n: {'f1': f1s[n], 'auc': aus[n]} for n in NAMES},
               'paired_tests': tests,
               'correction': {'n_test': n_test, 'n_train': n_train}},
              open(RESULTS / 'exp6_lr_check.json', 'w'), indent=2, default=float)
    print(f"Saved to {RESULTS/'exp6_lr_check.json'}")


if __name__ == '__main__':
    main()
