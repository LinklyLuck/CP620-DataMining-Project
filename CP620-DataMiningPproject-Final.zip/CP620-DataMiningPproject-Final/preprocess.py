import argparse
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'datasets' / 'brfss_raw.csv'
OUT_BAL = ROOT / 'datasets' / 'heart_disease_balanced.csv'
OUT_CLN = ROOT / 'datasets' / 'heart_disease_clean.csv'

TARGET_RAW = 'HeartDiseaseorAttack'      # column name in the raw file
TARGET_OUT = 'target'                    # column name in the working samples

N_BAL_PER_CLASS = 5000                   # balanced sample: 5,000 + 5,000
N_CLEAN = 15000                          # imbalanced sample: keeps the natural rate
SEED = 42


def load_raw():
    """Read the raw survey and rename the label column.

    Every column in this dataset is integer valued, so it is cast to int before
    writing. The raw file stores them as floats, and writing floats would produce
    "1.0" where the working samples contain "1".
    """
    raw = pd.read_csv(RAW)
    raw = raw.rename(columns={TARGET_RAW: TARGET_OUT})
    return raw.astype(int)


def build_balanced(pos, neg, seed=SEED):
    """Equal numbers of positives and negatives, then shuffle the rows together."""
    p = pos.sample(N_BAL_PER_CLASS, random_state=seed)
    n = neg.sample(N_BAL_PER_CLASS, random_state=seed)
    return pd.concat([p, n]).sample(frac=1.0, random_state=seed).reset_index(drop=True)


def build_clean(pos, neg, rate, seed=SEED):
    """Keep the natural positive rate of the full survey."""
    n_pos = int(round(N_CLEAN * rate))                 # 1,413 at the natural 9.4%
    n_neg = N_CLEAN - n_pos
    p = pos.sample(n_pos, random_state=seed)
    n = neg.sample(n_neg, random_state=seed)
    return pd.concat([p, n]).sample(frac=1.0, random_state=seed).reset_index(drop=True)


def count_overlap(a, b, feature_cols):
    """Count how many source rows the two samples share.

    Rows are matched on their full content, label included. The raw file has no
    respondent id, so two different respondents can have identical answers. This
    count is therefore an upper bound on true source-row overlap, but for these two
    files the overlap is structural rather than coincidental: the smaller draw of
    each class is a prefix of the larger one.
    """
    def key(df):
        return df[feature_cols + [TARGET_OUT]].astype(float).round(6) \
                 .astype(str).agg('|'.join, axis=1)
    from collections import Counter
    ca, cb = Counter(key(a)), Counter(key(b))
    total = sum(min(ca[k], cb[k]) for k in ca.keys() & cb.keys())

    def sub(df, y):
        return df[df[TARGET_OUT] == y]
    cap, cbp = Counter(key(sub(a, 1))), Counter(key(sub(b, 1)))
    can, cbn = Counter(key(sub(a, 0))), Counter(key(sub(b, 0)))
    pos = sum(min(cap[k], cbp[k]) for k in cap.keys() & cbp.keys())
    neg = sum(min(can[k], cbn[k]) for k in can.keys() & cbn.keys())
    return total, pos, neg


def main(disjoint=False):
    raw = load_raw()
    feature_cols = [c for c in raw.columns if c != TARGET_OUT]
    pos = raw[raw[TARGET_OUT] == 1]
    neg = raw[raw[TARGET_OUT] == 0]
    rate = raw[TARGET_OUT].mean()
    print(f"raw: {len(raw):,} rows, {len(pos):,} positive ({rate:.1%})")

    if not disjoint:
        # Default: reproduce the files the project actually used.
        balanced = build_balanced(pos, neg)
        clean = build_clean(pos, neg, rate)
    else:
        # Optional: draw the imbalanced sample first, then exclude it.
        clean = build_clean(pos, neg, rate)
        taken = set(clean.index)                       # indices into the raw frame
        clean_src = pd.concat([pos, neg]).loc[list(taken)] if False else None
        # rebuild using positional exclusion on the original frames
        clean_keys = set(clean.astype(str).agg('|'.join, axis=1))
        pos_left = pos[~pos.astype(str).agg('|'.join, axis=1).isin(clean_keys)]
        neg_left = neg[~neg.astype(str).agg('|'.join, axis=1).isin(clean_keys)]
        print(f"disjoint mode: {len(pos_left):,} positives and {len(neg_left):,} "
              f"negatives remain after removing the imbalanced sample")
        balanced = build_balanced(pos_left, neg_left)

    balanced.to_csv(OUT_BAL, index=False)
    clean.to_csv(OUT_CLN, index=False)
    print(f"wrote {OUT_BAL.name}: {len(balanced):,} rows, "
          f"{balanced[TARGET_OUT].mean():.1%} positive")
    print(f"wrote {OUT_CLN.name}: {len(clean):,} rows, "
          f"{clean[TARGET_OUT].mean():.1%} positive")

    total, p, n = count_overlap(balanced, clean, feature_cols)
    print(f"\nsource-row overlap between the two samples: {total:,} "
          f"({p:,} positive, {n:,} negative)")
    if total and not disjoint:
        print("This is expected. Both samples are drawn from the same pools with the "
              "same seed and\nneither excludes the other, so the smaller draw of each "
              "class sits inside the larger.\nThe two samples are used in separate "
              "experiments, each with its own internal\ncross-validation, so no row is "
              "ever in the training fold and the test fold of one fit.")


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--disjoint', action='store_true',
                    help='draw a genuinely disjoint pair (changes all downstream results)')
    args = ap.parse_args()
    main(disjoint=args.disjoint)
